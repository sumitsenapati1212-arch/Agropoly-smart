import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { SensorsFleetView } from './components/SensorsFleetView';
import { HistoricalAnalyticsView } from './components/HistoricalAnalyticsView';
import { IrrigationView } from './components/IrrigationView';
import { VentilationView } from './components/VentilationView';
import { CropsGuideView } from './components/CropsGuideView';
import { AiScannerView } from './components/AiScannerView';
import { FertilizerView } from './components/FertilizerView';
import { WeatherView } from './components/WeatherView';
import { CalculatorView } from './components/CalculatorView';
import { IotSetupView } from './components/IotSetupView';
import { SafetyModal } from './components/SafetyModal';
import { CROP_DATABASE } from './data/crops';
import {
  TelemetryPacket,
  ActuatorState,
  IrrigationLogEntry,
  ViewTab,
} from './types';

export function App() {
  const [systemMode, setSystemMode] = useState<'LIVE' | 'DEMO'>('DEMO');
  const [currentTab, setCurrentTab] = useState<ViewTab>('dashboard');
  const [activeCrop, setActiveCrop] = useState<string>('Tomato');

  // Actuator State
  const [pumpState, setPumpState] = useState<ActuatorState>({
    state: 'OFF',
    mode: 'AUTO',
    threshold: 50,
  });

  const [fanState, setFanState] = useState<ActuatorState>({
    state: 'OFF',
    mode: 'AUTO',
    threshold: 30.0,
  });

  // Telemetry & Logs
  const [telemetry, setTelemetry] = useState<TelemetryPacket | null>(null);
  const [history, setHistory] = useState<TelemetryPacket[]>([]);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [lastHeartbeatTime, setLastHeartbeatTime] = useState<number | null>(Date.now());
  const [irrigationLogs, setIrrigationLogs] = useState<IrrigationLogEntry[]>([
    {
      id: 'log-1',
      timestamp: new Date(Date.now() - 3600 * 2000).toISOString(),
      action: 'ON',
      reason: 'Auto Soil Threshold Trigger (< 50%)',
    },
    {
      id: 'log-2',
      timestamp: new Date(Date.now() - 3600 * 2000 + 600000).toISOString(),
      action: 'OFF',
      reason: '10-minute cycle completed',
    },
  ]);

  // Safety Confirmation Modal
  const [safetyAction, setSafetyAction] = useState<
    'PUMP_START' | 'PUMP_STOP' | 'FAN_START' | 'FAN_STOP' | null
  >(null);

  const cropProfile = CROP_DATABASE[activeCrop] || CROP_DATABASE['Tomato'];

  // Fetch initial history from server
  const fetchHistory = useCallback(async () => {
    try {
      const res = await fetch('/api/iot/history?limit=30');
      if (res.ok) {
        const data = await res.json();
        if (data.history && data.history.length > 0) {
          setHistory(data.history);
          setTelemetry(data.history[data.history.length - 1]);
        }
      }
    } catch (e) {
      console.warn('History fetch error:', e);
    }
  }, []);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  // Live Mode Poller
  useEffect(() => {
    if (systemMode !== 'LIVE') return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch('/api/iot/latest');
        if (res.ok) {
          const data = await res.json();
          if (data.reading) {
            setTelemetry(data.reading);
            setLastHeartbeatTime(new Date(data.reading.timestamp).getTime());
            setIsOnline(Date.now() - new Date(data.reading.timestamp).getTime() < 35000);
            setHistory((prev) => {
              const last = prev[prev.length - 1];
              if (!last || last.timestamp !== data.reading.timestamp) {
                return [...prev.slice(-49), data.reading];
              }
              return prev;
            });
          }
        }
      } catch (e) {
        setIsOnline(false);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [systemMode]);

  // Demo Simulation Engine
  useEffect(() => {
    if (systemMode !== 'DEMO') return;

    setIsOnline(true);
    const simInterval = setInterval(() => {
      setTelemetry((prev) => {
        const currentTemp = prev ? prev.temperature : 26.5;
        const currentHum = prev ? prev.humidity : 68;
        const currentSoil = prev ? prev.soil_moisture : 54;
        const currentWater = prev ? prev.water_level : 76;

        // Subtle realistic oscillation
        const newTemp = +(currentTemp + (Math.random() * 0.8 - 0.38)).toFixed(1);
        const newHum = Math.min(92, Math.max(40, Math.round(currentHum + (Math.random() * 2 - 1))));
        
        // Soil drops slowly unless pump is running
        let newSoil = currentSoil;
        if (pumpState.state === 'ON') {
          newSoil = Math.min(85, currentSoil + 4);
        } else {
          newSoil = Math.max(22, currentSoil - (Math.random() > 0.6 ? 1 : 0));
        }

        const newLight = Math.round(24000 + Math.random() * 4000 - 2000);
        const newCo2 = Math.round(720 + Math.random() * 60 - 30);
        const newWater = pumpState.state === 'ON' ? Math.max(15, currentWater - 1) : currentWater;

        const updated: TelemetryPacket = {
          device_id: 'POLYHOUSE_001',
          temperature: newTemp,
          humidity: newHum,
          soil_moisture: newSoil,
          light: newLight,
          co2: newCo2,
          water_level: newWater,
          timestamp: new Date().toISOString(),
        };

        setHistory((hist) => [...hist.slice(-49), updated]);
        setLastHeartbeatTime(Date.now());
        return updated;
      });
    }, 4000);

    return () => clearInterval(simInterval);
  }, [systemMode, pumpState.state]);

  // Automatic Relay Trigger Evaluator
  useEffect(() => {
    if (!telemetry) return;

    // Auto Pump Logic
    if (pumpState.mode === 'AUTO') {
      if (telemetry.soil_moisture < pumpState.threshold && telemetry.water_level >= 20) {
        if (pumpState.state !== 'ON') {
          setPumpState((p) => ({ ...p, state: 'ON' }));
          setIrrigationLogs((logs) => [
            {
              id: `log-${Date.now()}`,
              timestamp: new Date().toISOString(),
              action: 'ON',
              reason: `Automatic Soil Deficit Trigger (< ${pumpState.threshold}%)`,
            },
            ...logs.slice(0, 20),
          ]);
        }
      } else if (telemetry.soil_moisture >= pumpState.threshold + 15 || telemetry.water_level < 20) {
        if (pumpState.state === 'ON') {
          setPumpState((p) => ({ ...p, state: 'OFF' }));
          setIrrigationLogs((logs) => [
            {
              id: `log-${Date.now()}`,
              timestamp: new Date().toISOString(),
              action: 'OFF',
              reason:
                telemetry.water_level < 20
                  ? 'Low Reservoir Safeguard Lockout'
                  : 'Soil moisture replenished target reached',
            },
            ...logs.slice(0, 20),
          ]);
        }
      }
    }

    // Auto Fan Logic
    if (fanState.mode === 'AUTO') {
      if (telemetry.temperature > fanState.threshold) {
        if (fanState.state !== 'ON') {
          setFanState((f) => ({ ...f, state: 'ON' }));
        }
      } else if (telemetry.temperature <= fanState.threshold - 1.5) {
        if (fanState.state === 'ON') {
          setFanState((f) => ({ ...f, state: 'OFF' }));
        }
      }
    }
  }, [telemetry, pumpState.mode, pumpState.threshold, pumpState.state, fanState.mode, fanState.threshold, fanState.state]);

  // Handle Confirmed Safety Actions
  const handleConfirmSafetyAction = () => {
    if (!safetyAction) return;

    if (safetyAction === 'PUMP_START') {
      setPumpState((p) => ({ ...p, state: 'ON', mode: 'MANUAL' }));
      setIrrigationLogs((logs) => [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'ON',
          reason: 'Manual Operator Activation',
        },
        ...logs.slice(0, 20),
      ]);
    } else if (safetyAction === 'PUMP_STOP') {
      setPumpState((p) => ({ ...p, state: 'OFF' }));
      setIrrigationLogs((logs) => [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'OFF',
          reason: 'Manual Operator Stop',
        },
        ...logs.slice(0, 20),
      ]);
    } else if (safetyAction === 'FAN_START') {
      setFanState((f) => ({ ...f, state: 'ON', mode: 'MANUAL' }));
    } else if (safetyAction === 'FAN_STOP') {
      setFanState((f) => ({ ...f, state: 'OFF' }));
    }
    setSafetyAction(null);
  };

  const handleSendTestPacket = async (packet: any) => {
    const res = await fetch('/api/iot/readings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(packet),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to ingest packet');
    }
    const data = await res.json();
    if (data.packet) {
      setTelemetry(data.packet);
      setLastHeartbeatTime(Date.now());
      setIsOnline(true);
      setHistory((prev) => [...prev.slice(-49), data.packet]);
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f7f2] text-slate-800 flex flex-col font-sans antialiased selection:bg-emerald-600/20 selection:text-[#0C3823]">
      {/* Universal Top Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => setCurrentTab(tab)}
        systemMode={systemMode}
        onToggleMode={() =>
          setSystemMode((m) => (m === 'LIVE' ? 'DEMO' : 'LIVE'))
        }
        isOnline={isOnline}
        activeCrop={activeCrop}
        onChangeCrop={(crop) => setActiveCrop(crop)}
        cropList={Object.keys(CROP_DATABASE)}
        lastHeartbeatTime={lastHeartbeatTime}
      />

      {/* Main Responsive Canvas Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'dashboard' && (
          <DashboardView
            telemetry={telemetry}
            cropProfile={cropProfile}
            pumpState={pumpState}
            fanState={fanState}
            isOnline={isOnline}
            history={history}
            onNavigate={(tab) => setCurrentTab(tab)}
          />
        )}

        {currentTab === 'sensors' && (
          <SensorsFleetView
            telemetry={telemetry}
            isOnline={isOnline}
            cropProfile={cropProfile}
          />
        )}

        {currentTab === 'history' && (
          <HistoricalAnalyticsView
            history={history}
            cropProfile={cropProfile}
          />
        )}

        {currentTab === 'irrigation' && (
          <IrrigationView
            pumpState={pumpState}
            telemetry={telemetry}
            onSetPumpMode={(mode) => setPumpState((p) => ({ ...p, mode }))}
            onSetThreshold={(threshold) => setPumpState((p) => ({ ...p, threshold }))}
            onRequestAction={(action) => setSafetyAction(action)}
            logs={irrigationLogs}
          />
        )}

        {currentTab === 'ventilation' && (
          <VentilationView
            fanState={fanState}
            telemetry={telemetry}
            cropProfile={cropProfile}
            onSetFanMode={(mode) => setFanState((f) => ({ ...f, mode }))}
            onSetThreshold={(threshold) => setFanState((f) => ({ ...f, threshold }))}
            onRequestAction={(action) => setSafetyAction(action)}
          />
        )}

        {currentTab === 'crops' && (
          <CropsGuideView
            activeCrop={activeCrop}
            onSelectCrop={(crop) => setActiveCrop(crop)}
          />
        )}

        {currentTab === 'ai-scanner' && (
          <AiScannerView activeCrop={activeCrop} />
        )}

        {currentTab === 'fertilizer' && (
          <FertilizerView activeCrop={activeCrop} />
        )}

        {currentTab === 'weather' && <WeatherView />}

        {currentTab === 'calculator' && <CalculatorView />}

        {currentTab === 'iot-setup' && (
          <IotSetupView
            onSendTestPacket={handleSendTestPacket}
            isOnline={isOnline}
          />
        )}
      </main>

      {/* Safety Confirmation Modal for Physical Relays */}
      <SafetyModal
        actionType={safetyAction}
        onConfirm={handleConfirmSafetyAction}
        onClose={() => setSafetyAction(null)}
      />

      {/* Footer */}
      <footer className="border-t border-emerald-900/10 bg-white py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center text-[11px] font-mono text-slate-500 gap-2">
          <div className="flex items-center gap-3">
            <span className="text-[#0C3823] font-bold">AGROPOLY <span className="text-emerald-700 font-extrabold">SMART</span> NODE v2.4</span>
            <span className="text-slate-300">|</span>
            <span className="text-slate-500 uppercase tracking-widest text-[10px]">Encryption: TLS 1.3 | AES-256-GCM</span>
          </div>
          <div className="flex items-center space-x-4 text-[10px] text-slate-600">
            <span>ESP32 BUS: <strong className="text-emerald-700">OK</strong></span>
            <span>•</span>
            <span>CYCLE: <strong className="text-[#0C3823]">2.0s</strong></span>
            <span>•</span>
            <span>ICAR PROTOCOLS: <strong className="text-[#0C3823]">ACTIVE</strong></span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
