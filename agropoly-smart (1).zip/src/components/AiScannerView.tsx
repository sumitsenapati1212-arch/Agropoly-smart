import React, { useState, useRef } from 'react';
import {
  ScanLine,
  UploadCloud,
  Camera,
  Sparkles,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  FileCheck,
  Zap,
  FlaskConical,
  Sprout,
  Activity,
  Layers,
} from 'lucide-react';
import { LeafDiagnosisResult } from '../types';

interface AiScannerViewProps {
  activeCrop: string;
}

const SAMPLE_LEAF_PRESETS = [
  {
    id: 'sample-1',
    name: 'Tomato Early Blight & Iron Chlorosis',
    crop: 'Tomato',
    description: 'Target-board lesions on bottom foliage + interveinal apical yellowing',
    base64: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkWPjfDwAEeQHzc1pUDAAAAABJRU5ErkJggg==',
  },
  {
    id: 'sample-2',
    name: 'Capsicum Powdery Mildew & Magnesium Deficit',
    crop: 'Capsicum',
    description: 'Yellow chlorotic upper blotches + inverted V-shape margin chlorosis',
    base64: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkWPjfDwAEeQHzc1pUDAAAAABJRU5ErkJggg==',
  },
  {
    id: 'sample-3',
    name: 'Cucumber Downy Mildew & K Scorch',
    crop: 'Cucumber',
    description: 'Angular yellow vein lesions strictly bounded + leaf tip marginal scorch',
    base64: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkWPjfDwAEeQHzc1pUDAAAAABJRU5ErkJggg==',
  },
  {
    id: 'sample-4',
    name: 'Strawberry Spider Mites & Ca Deficiency',
    crop: 'Strawberry',
    description: 'Bronzed stippling + tip burn on young heart leaves & calyx',
    base64: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkWPjfDwAEeQHzc1pUDAAAAABJRU5ErkJggg==',
  },
];

export const AiScannerView: React.FC<AiScannerViewProps> = ({ activeCrop }) => {
  const [selectedCrop, setSelectedCrop] = useState<string>(activeCrop || 'Tomato');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [diagnosisResult, setDiagnosisResult] = useState<LeafDiagnosisResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setImagePreview(event.target?.result as string);
      setDiagnosisResult(null);
      setErrorMsg(null);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPreset = (preset: typeof SAMPLE_LEAF_PRESETS[0]) => {
    setSelectedCrop(preset.crop);
    setImagePreview(preset.base64);
    setDiagnosisResult(null);
    setErrorMsg(null);
  };

  const handleRunDiagnosis = async () => {
    if (!imagePreview) {
      setErrorMsg('Please upload a leaf photograph or select a field preset first.');
      return;
    }

    setIsDiagnosing(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/gemini/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imagePreview,
          mimeType: 'image/jpeg',
          crop: selectedCrop,
        }),
      });

      const data = await response.json();
      if (data.success && data.result) {
        setDiagnosisResult({
          ...data.result,
          source: data.source === 'gemini-ai' ? 'Gemini 2.5 Vision AI' : 'Expert Agronomic Diagnostic Model',
        });
      } else {
        throw new Error(data.error || 'Failed to complete diagnosis');
      }
    } catch (err: any) {
      console.error('Diagnosis failed:', err);
      setErrorMsg(err.message || 'Error communicating with AI diagnostic service');
    } finally {
      setIsDiagnosing(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-base font-bold text-[#0C3823] font-mono uppercase tracking-wider flex items-center space-x-2">
            <ScanLine className="w-5 h-5 text-emerald-600" />
            <span>AI Crop Health, Pathology & Nutrient Deficiency Scanner</span>
          </h2>
          <p className="text-xs text-slate-600">
            Powered by multimodal Gemini Vision model and verified protected cultivation agronomy rulebases
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Upload & Controls Panel */}
        <div className="lg:col-span-5 bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-4">
          <div>
            <label className="text-[11px] font-bold uppercase text-[#0C3823] tracking-wide block mb-1.5 font-mono">
              1. Target Polyhouse Crop Type
            </label>
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="w-full bg-[#f7f9f5] border border-slate-300 rounded-lg px-3 py-2.5 text-xs font-bold text-slate-800 outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 cursor-pointer"
            >
              <option value="Tomato">Tomato (Solanum lycopersicum)</option>
              <option value="Capsicum">Capsicum / Bell Pepper</option>
              <option value="Cucumber">Cucumber (Cucumis sativus)</option>
              <option value="Strawberry">Strawberry (Fragaria)</option>
              <option value="Rose">Dutch Rose (Rosa hybrida)</option>
              <option value="Gerbera">Gerbera (Gerbera jamesonii)</option>
              <option value="Lettuce">Lettuce (Lactuca sativa)</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold uppercase text-[#0C3823] tracking-wide block mb-1.5 font-mono">
              2. Upload Foliar Leaf Photograph
            </label>

            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />

            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-emerald-800/20 hover:border-emerald-600 hover:bg-emerald-50/50 rounded-xl p-6 text-center transition cursor-pointer flex flex-col items-center justify-center space-y-2 bg-[#f7f9f5]/60"
            >
              <div className="p-3 bg-emerald-100 text-emerald-800 rounded-xl border border-emerald-300">
                <UploadCloud className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-800">
                  Click to browse or drag & drop leaf photo
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5">Supports JPG, PNG, WEBP (Camera capture supported)</p>
              </div>
            </div>
          </div>

          {/* Quick Presets for Demo */}
          <div className="space-y-2">
            <p className="text-[11px] font-bold uppercase text-[#0C3823] tracking-wide font-mono">
              Or Select Verified Field Presets:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SAMPLE_LEAF_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => handleSelectPreset(preset)}
                  className={`p-2.5 rounded-lg border text-left transition cursor-pointer ${
                    selectedCrop === preset.crop && imagePreview === preset.base64
                      ? 'bg-emerald-50 border-emerald-500 shadow-xs'
                      : 'bg-[#f7f9f5] hover:bg-emerald-50/50 border-slate-200'
                  }`}
                >
                  <p className="text-xs font-bold text-[#0C3823]">{preset.crop}</p>
                  <p className="text-[10px] text-slate-600 truncate">{preset.name}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Action Button */}
          <button
            onClick={handleRunDiagnosis}
            disabled={isDiagnosing || !imagePreview}
            className={`w-full py-3 px-4 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer shadow-xs ${
              isDiagnosing || !imagePreview
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
                : 'bg-[#0C3823] hover:bg-[#134e2e] text-white'
            }`}
          >
            {isDiagnosing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-emerald-300" />
                <span>Analyzing Foliar Pathogens & Deficiencies...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-emerald-300" />
                <span>Run AI Diagnostic Scan</span>
              </>
            )}
          </button>

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
        </div>

        {/* Diagnosis Results Display */}
        <div className="lg:col-span-7 bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-xs font-bold text-[#0C3823] uppercase tracking-wider flex items-center space-x-2 font-mono">
                <FileCheck className="w-4 h-4 text-emerald-600" />
                <span>Pathology Diagnosis, Nutrient Analysis & IPM Prescription</span>
              </h3>
              {diagnosisResult && (
                <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 font-mono">
                  {diagnosisResult.confidence} CONFIDENCE
                </span>
              )}
            </div>

            {isDiagnosing ? (
              <div className="py-20 text-center space-y-3">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto border border-emerald-300">
                  <RefreshCw className="w-6 h-6 animate-spin" />
                </div>
                <p className="text-sm font-bold text-[#0C3823]">
                  Transmitting leaf matrix to AI Vision Model...
                </p>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Cross-referencing against certified protected cultivation disease signatures & micronutrient deficiency spectra
                </p>
              </div>
            ) : diagnosisResult ? (
              <div className="mt-4 space-y-4">
                {/* Main Diagnosis Card */}
                <div className="p-4 bg-[#f7f9f5] rounded-xl border border-emerald-900/10 space-y-1.5">
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-1">
                    <div>
                      <h4 className="text-base font-black text-[#0C3823]">
                        {diagnosisResult.diagnosedName}
                      </h4>
                      <p className="text-xs font-bold text-emerald-700">
                        {diagnosisResult.causalAgent}
                      </p>
                    </div>
                    <span className="text-[10px] font-mono text-slate-600 bg-white px-2 py-0.5 rounded border border-slate-200 shrink-0 self-start">
                      Engine: {diagnosisResult.source}
                    </span>
                  </div>
                </div>

                {/* Nutrient Deficiency Section */}
                {diagnosisResult.nutrientDeficiency && (
                  <div className="p-4 bg-amber-50/70 rounded-xl border border-amber-200 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <FlaskConical className="w-4 h-4 text-amber-700" />
                        <h5 className="text-xs font-bold uppercase text-amber-900 font-mono tracking-wider">
                          Nutrient Deficiency Assessment: {diagnosisResult.nutrientDeficiency.element}
                        </h5>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-200 text-amber-900 border border-amber-300 uppercase">
                        {diagnosisResult.nutrientDeficiency.severity}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div className="bg-white p-2.5 rounded-lg border border-amber-200/80">
                        <span className="text-[10px] font-bold uppercase text-slate-500 block">Visual Foliar Symptoms:</span>
                        <p className="text-slate-700 text-[11px] mt-0.5">{diagnosisResult.nutrientDeficiency.visualSigns}</p>
                      </div>
                      <div className="bg-white p-2.5 rounded-lg border border-amber-200/80">
                        <span className="text-[10px] font-bold uppercase text-slate-500 block">Prescribed Stock Tank:</span>
                        <p className="text-emerald-700 font-bold text-[11px] mt-0.5">
                          {diagnosisResult.nutrientDeficiency.stockTank} ({diagnosisResult.nutrientDeficiency.prescription})
                        </p>
                      </div>
                    </div>

                    <div className="bg-white p-2.5 rounded-lg border border-amber-200/80 text-xs">
                      <span className="text-[10px] font-bold uppercase text-slate-500 block">Exact Dosage & Fertigation Protocol:</span>
                      <p className="text-slate-800 font-semibold text-[11px] mt-0.5">{diagnosisResult.nutrientDeficiency.dosage}</p>
                    </div>
                  </div>
                )}

                {/* Foliar Symptoms */}
                <div className="space-y-1 text-xs">
                  <strong className="text-[#0C3823] font-bold uppercase text-[10px] font-mono tracking-wider">
                    Observed Pathology Symptoms:
                  </strong>
                  <p className="text-slate-700 bg-[#f7f9f5] p-3 rounded-lg border border-slate-200 leading-relaxed text-[11px]">
                    {diagnosisResult.symptoms}
                  </p>
                </div>

                {/* IPM Recommendations */}
                <div className="space-y-2 text-xs">
                  <strong className="text-[#0C3823] font-bold uppercase text-[10px] font-mono tracking-wider">
                    Integrated Pest & Disease Management (IPM) Protocols:
                  </strong>
                  <ul className="space-y-1.5">
                    {diagnosisResult.ipmRecommendations.map((rec, i) => (
                      <li
                        key={i}
                        className="p-2.5 bg-emerald-50 rounded-lg border border-emerald-200 text-slate-800 flex items-start space-x-2 text-[11px]"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span className="leading-relaxed">{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              <div className="py-20 text-center space-y-2 text-slate-500">
                <div className="w-12 h-12 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto border border-slate-200">
                  <ScanLine className="w-6 h-6" />
                </div>
                <p className="text-xs font-bold text-slate-700">No Diagnosis Executed Yet</p>
                <p className="text-[11px] max-w-sm mx-auto text-slate-500">
                  Upload an image of an affected polyhouse leaf or select a field preset above to diagnose pathogens and nutrient deficiencies.
                </p>
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-100 text-[10px] text-slate-500 flex items-center justify-between font-mono">
            <span>Standardized under ICAR & Good Agricultural Practices (GAP)</span>
            <span>Real-Time Diagnostic Ingestion</span>
          </div>
        </div>
      </div>
    </div>
  );
};
