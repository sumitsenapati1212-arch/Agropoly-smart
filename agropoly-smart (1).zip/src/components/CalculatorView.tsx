import React, { useState } from 'react';
import {
  Calculator,
  TrendingUp,
  DollarSign,
  PieChart,
  Percent,
  CheckCircle,
  Sparkles,
} from 'lucide-react';

export const CalculatorView: React.FC = () => {
  const [areaSqM, setAreaSqM] = useState<number>(1000);
  const [cropType, setCropType] = useState<string>('Capsicum');
  const [yieldPerSqM, setYieldPerSqM] = useState<number>(12); // kg/sq.m or stems
  const [pricePerUnit, setPricePerUnit] = useState<number>(45); // ₹ or $
  const [opexPerSqM, setOpexPerSqM] = useState<number>(180); // ₹/sq.m
  const [capexPerSqM, setCapexPerSqM] = useState<number>(1050); // ₹/sq.m polyhouse structure + automation
  const [subsidyPercent, setSubsidyPercent] = useState<number>(50); // National Horticulture Board (NHB) subsidy

  // Financial calculations
  const totalCapex = areaSqM * capexPerSqM;
  const netFarmerCapex = totalCapex * ((100 - subsidyPercent) / 100);

  const totalAnnualYieldKg = areaSqM * yieldPerSqM;
  const grossAnnualRevenue = totalAnnualYieldKg * pricePerUnit;
  const totalAnnualOpex = areaSqM * opexPerSqM;
  const netAnnualProfit = grossAnnualRevenue - totalAnnualOpex;

  const paybackPeriodYears = netAnnualProfit > 0 ? (netFarmerCapex / netAnnualProfit).toFixed(1) : 'N/A';
  const roiPercentage = netFarmerCapex > 0 ? ((netAnnualProfit / netFarmerCapex) * 100).toFixed(1) : '0';

  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-base font-bold text-[#0C3823] font-mono uppercase tracking-wider flex items-center space-x-2">
            <Calculator className="w-5 h-5 text-emerald-600" />
            <span>Polyhouse Farming Economics & ROI Calculator</span>
          </h2>
          <p className="text-xs text-slate-600">
            Model capital expenditure (CapEx), operational expenditure (OpEx), government subsidies, and net commercial payback periods
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 font-mono">
        {/* Parameters Form */}
        <div className="lg:col-span-6 bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-4">
          <h3 className="text-xs font-bold text-[#0C3823] uppercase tracking-wider border-b border-slate-100 pb-2">
            Commercial Parameters & Subsidies
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                Polyhouse Area (m²):
              </label>
              <input
                type="number"
                value={areaSqM}
                onChange={(e) => setAreaSqM(Math.max(100, parseInt(e.target.value) || 0))}
                className="w-full bg-[#f7f9f5] border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold text-[#0C3823] outline-none focus:border-emerald-600"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                Crop Enterprise:
              </label>
              <select
                value={cropType}
                onChange={(e) => setCropType(e.target.value)}
                className="w-full bg-[#f7f9f5] border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold text-[#0C3823] outline-none focus:border-emerald-600 cursor-pointer"
              >
                <option value="Capsicum">Colored Bell Pepper / Capsicum</option>
                <option value="Tomato">Indeterminate Polyhouse Tomato</option>
                <option value="Cucumber">Parthenocarpic English Cucumber</option>
                <option value="Dutch Rose">Dutch Cut Roses (Stems)</option>
                <option value="Strawberry">High-Tunnel Strawberry</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                Yield (kg/m² or stems):
              </label>
              <input
                type="number"
                value={yieldPerSqM}
                onChange={(e) => setYieldPerSqM(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#f7f9f5] border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold text-[#0C3823] outline-none focus:border-emerald-600"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                Selling Price (₹/unit):
              </label>
              <input
                type="number"
                value={pricePerUnit}
                onChange={(e) => setPricePerUnit(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#f7f9f5] border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold text-[#0C3823] outline-none focus:border-emerald-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                OpEx (₹/m²):
              </label>
              <input
                type="number"
                value={opexPerSqM}
                onChange={(e) => setOpexPerSqM(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#f7f9f5] border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold text-[#0C3823] outline-none focus:border-emerald-600"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                CapEx (₹/m²):
              </label>
              <input
                type="number"
                value={capexPerSqM}
                onChange={(e) => setCapexPerSqM(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#f7f9f5] border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold text-[#0C3823] outline-none focus:border-emerald-600"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                Subsidy (%):
              </label>
              <input
                type="number"
                value={subsidyPercent}
                onChange={(e) => setSubsidyPercent(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#f7f9f5] border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold text-[#0C3823] outline-none focus:border-emerald-600"
              />
            </div>
          </div>

          <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900 flex items-start space-x-2.5">
            <Sparkles className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <span className="text-[11px] leading-relaxed font-sans">
              <strong className="text-emerald-900 font-mono">Precision Automation Advantage:</strong> Automated drip and ventilation reduce labor costs by 40% and cut fertilizer losses by 30%, increasing net yield by up to 25%.
            </span>
          </div>
        </div>

        {/* Financial ROI Output Display */}
        <div className="lg:col-span-6 bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <h3 className="text-xs font-bold text-[#0C3823] uppercase tracking-wider border-b border-slate-100 pb-2">
              Annual Profitability & Capital Payback Statement
            </h3>

            <div className="grid grid-cols-2 gap-3 mt-3">
              <div className="p-3.5 bg-[#f7f9f5] rounded-xl border border-slate-200">
                <p className="text-[9px] font-bold uppercase text-slate-500">Gross Annual Revenue</p>
                <p className="text-lg font-bold text-[#0C3823] mt-1">
                  ₹ {grossAnnualRevenue.toLocaleString()}
                </p>
                <p className="text-[10px] text-slate-500">{(totalAnnualYieldKg / 1000).toFixed(1)} MT Harvest</p>
              </div>

              <div className="p-3.5 bg-[#f7f9f5] rounded-xl border border-slate-200">
                <p className="text-[9px] font-bold uppercase text-slate-500">Annual Operational OpEx</p>
                <p className="text-lg font-bold text-slate-700 mt-1">
                  ₹ {totalAnnualOpex.toLocaleString()}
                </p>
                <p className="text-[10px] text-slate-500">Power, nutrients & labor</p>
              </div>
            </div>

            <div className="mt-3.5 p-4 bg-emerald-50/50 border border-emerald-300 rounded-xl space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-emerald-800 font-bold">
                    Net Estimated Annual Profit
                  </p>
                  <p className="text-2xl font-bold text-[#0C3823] mt-0.5">₹ {netAnnualProfit.toLocaleString()}</p>
                </div>
                <div className="bg-emerald-100 border border-emerald-300 p-2 rounded-lg">
                  <TrendingUp className="w-5 h-5 text-emerald-800" />
                </div>
              </div>

              <div className="pt-2.5 border-t border-emerald-200/60 grid grid-cols-2 gap-2 text-xs">
                <div>
                  <p className="text-slate-600 text-[9px] uppercase font-bold">Farmer Net CapEx</p>
                  <p className="font-bold text-[#0C3823] text-xs">₹ {netFarmerCapex.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-slate-600 text-[9px] uppercase font-bold">Estimated Payback</p>
                  <p className="font-bold text-emerald-700 text-xs">{paybackPeriodYears} Years</p>
                </div>
              </div>
            </div>
          </div>

          <div className="p-3 bg-[#f7f9f5] rounded-xl border border-slate-200 text-[11px] text-slate-600 flex justify-between">
            <span>Projected Annual ROI: <strong className="text-emerald-700">{roiPercentage}%</strong></span>
            <span>Based on {subsidyPercent}% NHB Grant</span>
          </div>
        </div>
      </div>
    </div>
  );
};
