import React from 'react';
import { CROP_DATABASE } from '../data/crops';
import { Thermometer, CloudRain, Sprout, Sun, Check, BookOpen } from 'lucide-react';

interface CropsGuideViewProps {
  activeCrop: string;
  onSelectCrop: (crop: string) => void;
}

export const CropsGuideView: React.FC<CropsGuideViewProps> = ({
  activeCrop,
  onSelectCrop,
}) => {
  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
        <div>
          <h2 className="text-base font-bold text-[#0C3823] font-mono uppercase tracking-wider flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-emerald-600" />
            <span>Verified Agronomic Polyhouse Crop Directory</span>
          </h2>
          <p className="text-xs text-slate-600">
            Certified microclimate parameters, phenological stages, and IPM protocols based on ICAR & FAO polyhouse cultivation benchmarks
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {Object.keys(CROP_DATABASE).map((cropKey) => {
          const crop = CROP_DATABASE[cropKey];
          const isSelected = activeCrop === cropKey;

          return (
            <div
              key={cropKey}
              className={`bg-white rounded-xl border p-5 space-y-4 transition duration-150 shadow-xs ${
                isSelected
                  ? 'border-emerald-600 ring-2 ring-emerald-600/20'
                  : 'border-emerald-900/10 hover:border-emerald-600/50'
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-bold text-[#0C3823] uppercase font-mono">{crop.name}</h3>
                  <p className="text-[11px] text-slate-500 italic font-sans">{crop.scientificName}</p>
                </div>
                {isSelected ? (
                  <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded text-[10px] font-bold font-mono bg-emerald-100 text-emerald-800 border border-emerald-300">
                    <Check className="w-3 h-3" />
                    <span>ACTIVE</span>
                  </span>
                ) : (
                  <button
                    onClick={() => onSelectCrop(cropKey)}
                    className="px-3 py-1 rounded-lg text-[11px] font-bold font-mono bg-[#f7f9f5] hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border border-slate-200 transition cursor-pointer"
                  >
                    Select Profile
                  </button>
                )}
              </div>

              {/* Vital Agronomic Metrics */}
              <div className="grid grid-cols-2 gap-2 text-xs bg-[#f7f9f5] p-3 rounded-xl border border-emerald-900/10 font-mono">
                <div className="flex items-center space-x-1.5 text-slate-700 text-[11px]">
                  <Thermometer className="w-3.5 h-3.5 text-orange-600 shrink-0" />
                  <span>
                    Temp: <strong className="text-[#0C3823]">{crop.tempRange[0]}-{crop.tempRange[1]}°C</strong>
                  </span>
                </div>
                <div className="flex items-center space-x-1.5 text-slate-700 text-[11px]">
                  <CloudRain className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>
                    Hum: <strong className="text-[#0C3823]">{crop.humRange[0]}-{crop.humRange[1]}%</strong>
                  </span>
                </div>
                <div className="flex items-center space-x-1.5 text-slate-700 text-[11px]">
                  <Sprout className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>
                    Soil: <strong className="text-[#0C3823]">&gt; {crop.soilTarget}%</strong>
                  </span>
                </div>
                <div className="flex items-center space-x-1.5 text-slate-700 text-[11px]">
                  <Sun className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>
                    VPD: <strong className="text-[#0C3823]">{crop.vpdTarget}</strong>
                  </span>
                </div>
              </div>

              {/* Growth Cycle */}
              <div className="text-xs space-y-1">
                <p className="text-[10px] uppercase font-bold text-slate-500 font-mono">Phenological Stages</p>
                <p className="text-slate-700 text-[11px] leading-relaxed bg-[#f7f9f5] p-2.5 rounded-lg border border-slate-200">
                  {crop.stages}
                </p>
              </div>

              {/* Diseases & Pests */}
              <div className="text-xs space-y-1">
                <p className="text-[10px] uppercase font-bold text-slate-500 font-mono">Common Pathogens & Pests</p>
                <div className="flex flex-wrap gap-1.5">
                  {crop.diseases.slice(0, 2).map((d, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-mono font-medium"
                    >
                      {d}
                    </span>
                  ))}
                  {crop.pests.slice(0, 2).map((p, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded bg-rose-50 text-rose-800 border border-rose-200 text-[10px] font-mono font-medium"
                    >
                      {p}
                    </span>
                  ))}
                </div>
              </div>

              {/* EC & pH */}
              <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-600 font-mono flex justify-between">
                <span>{crop.idealEcPh}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
