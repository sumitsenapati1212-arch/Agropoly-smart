import React, { useEffect, useRef } from 'react';
import {
  Cpu,
  Droplets,
  Fan,
  Trees,
  Thermometer,
  CloudRain,
  Sprout,
  Sun,
  Wind,
  Gauge,
  Activity,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Bug,
  ShieldAlert,
  ArrowRight,
  Radio,
  Wifi,
  Database,
  Layers,
} from 'lucide-react';
import { Chart, registerables } from 'chart.js';
import { TelemetryPacket, CropProfile, ActuatorState } from '../types';

Chart.register(...registerables);

interface DashboardViewProps {
  telemetry: TelemetryPacket | null;
  cropProfile: CropProfile;
  pumpState: ActuatorState;
  fanState: ActuatorState;
  isOnline: boolean;
  history: TelemetryPacket[];
  onNavigate: (tab: any) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  telemetry,
  cropProfile,
  pumpState,
  fanState,
  isOnline,
  history,
  onNavigate,
}) => {
  const chartCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstanceRef = useRef<Chart | null>(null);

  // Initialize and update the live sliding chart
  useEffect(() => {
    if (!chartCanvasRef.current) return;

    const ctx = chartCanvasRef.current.getContext('2d');
    if (!ctx) return;

    // Use recent 12 data points
    const recent = history.slice(-12);
    const labels = recent.map((p) => {
      const d = new Date(p.timestamp);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    });
    const tempData = recent.map((p) => p.temperature);
    const humData = recent.map((p) => p.humidity);

    if (chartInstanceRef.current) {
      chartInstanceRef.current.data.labels = labels;
      chartInstanceRef.current.data.datasets[0].data = tempData;
      chartInstanceRef.current.data.datasets[1].data = humData;
      chartInstanceRef.current.update('none');
    } else {
      chartInstanceRef.current = new Chart(ctx, {
        type: 'line',
        data: {
          labels,
          datasets: [
            {
              label: 'Air Temp (°C)',
              data: tempData,
              borderColor: '#ea580c',
              backgroundColor: 'rgba(234, 88, 12, 0.08)',
              borderWidth: 2.5,
              tension: 0.35,
              fill: true,
              pointRadius: 4,
              pointHoverRadius: 7,
              pointBackgroundColor: '#ea580c',
              yAxisID: 'yTemp',
            },
            {
              label: 'Humidity (%)',
              data: humData,
              borderColor: '#0284c7',
              backgroundColor: 'rgba(2, 132, 199, 0.08)',
              borderWidth: 2.5,
              tension: 0.35,
              fill: true,
              pointRadius: 4,
              pointHoverRadius: 7,
              pointBackgroundColor: '#0284c7',
              yAxisID: 'yHum',
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: {
            mode: 'index',
            intersect: false,
          },
          plugins: {
            legend: {
              display: false,
            },
            tooltip: {
              backgroundColor: '#0C3823',
              borderColor: '#14532d',
              borderWidth: 1,
              titleColor: '#ffffff',
              bodyColor: '#e2e8f0',
              titleFont: { size: 12, weight: 'bold' },
              padding: 12,
              cornerRadius: 8,
            },
          },
          scales: {
            x: {
              grid: { color: 'rgba(226, 232, 240, 0.8)' },
              ticks: { font: { size: 11, family: 'monospace' }, color: '#64748b' },
            },
            yTemp: {
              type: 'linear',
              position: 'left',
              grid: { color: 'rgba(226, 232, 240, 0.8)' },
              ticks: {
                font: { size: 11, family: 'monospace' },
                color: '#ea580c',
                callback: (val) => `${val}°C`,
              },
            },
            yHum: {
              type: 'linear',
              position: 'right',
              grid: { display: false },
              ticks: {
                font: { size: 11, family: 'monospace' },
                color: '#0284c7',
                callback: (val) => `${val}%`,
              },
              min: 20,
              max: 100,
            },
          },
        },
      });
    }

    return () => {
      // Keep chart alive during fast updates
    };
  }, [history]);

  // Automated Pest, Disease & Environmental Risk Engine
  const alerts: {
    type: 'warn' | 'danger' | 'pest' | 'info';
    category: string;
    message: string;
    action: string;
    targetTab: string;
  }[] = [];

  if (telemetry) {
    const temp = telemetry.temperature;
    const hum = telemetry.humidity;
    const crop = cropProfile.name.toLowerCase();

    // 1. Fungal / Early Blight Risk (High humidity > 80% + Warm temp > 24°C)
    if (hum > 80 && temp > 24) {
      alerts.push({
        type: 'pest',
        category: 'FUNGAL PATHOGEN RISK',
        message: `High Early Blight / Alternaria Spore Hazard for ${cropProfile.name}: Canopy humidity (${hum}%) and temperature (${temp}°C) create optimal spore germination conditions.`,
        action: 'Engage Gable Fans & Apply Bio-Fungicide (Trichoderma)',
        targetTab: 'ventilation',
      });
    }

    // 2. Powdery Mildew Risk (Moderate-High humidity > 70% + Mild-warm temp 20-28°C)
    else if (hum > 70 && temp >= 20 && temp <= 28) {
      alerts.push({
        type: 'pest',
        category: 'POWDERY MILDEW RISK',
        message: `Powdery Mildew Risk Detected: Favorable microclimate for foliar mycelium expansion.`,
        action: 'Increase Canopy Airflow & Check Foliage in AI Scanner',
        targetTab: 'ai-scanner',
      });
    }

    // 3. Hot & Dry Spider Mite Risk (Low humidity < 50% + High temp > 28°C)
    if (hum < 50 && temp > 28) {
      alerts.push({
        type: 'pest',
        category: 'PEST INFESTATION HAZARD',
        message: `Spider Mite Outbreak Alert: Hot (${temp}°C) and dry (${hum}%) conditions rapidly accelerate Tetranychus mite reproduction cycles.`,
        action: 'Engage Overhead Misting & Check Crop Guide for Biocontrol',
        targetTab: 'crops',
      });
    }

    // 4. Botrytis Grey Mould (Very high humidity > 85% + Cool temp < 22°C)
    if (hum > 85 && temp < 22) {
      alerts.push({
        type: 'pest',
        category: 'BOTRYTIS GREY MOULD RISK',
        message: `Botrytis Grey Mould Hazard: Cold damp canopy conditions favor fungal sporulation on floral organs and stem nodes.`,
        action: 'Run Exhaust Fans to Vent Moisture',
        targetTab: 'ventilation',
      });
    }

    // 5. Soil Moisture Depletion
    if (telemetry.soil_moisture < pumpState.threshold) {
      alerts.push({
        type: 'warn',
        category: 'ROOT ZONE WATER DEFICIT',
        message: `Soil Moisture Deficit (${telemetry.soil_moisture}% vs Setpoint < ${pumpState.threshold}%). Auto-irrigation engaged.`,
        action: 'Review Drip Schedule & Tank A/B Dosing',
        targetTab: 'irrigation',
      });
    }

    // 6. Canopy Thermal Cap
    if (telemetry.temperature > fanState.threshold) {
      alerts.push({
        type: 'danger',
        category: 'THERMAL SHOCK ALERT',
        message: `High Canopy Temperature Alert (${telemetry.temperature}°C vs Setpoint > ${fanState.threshold}°C). Automated exhaust ventilation running.`,
        action: 'Check Gable Relay & Shade Screen',
        targetTab: 'ventilation',
      });
    }

    // 7. Water Tank Low Level Safeguard
    if (telemetry.water_level < 20) {
      alerts.push({
        type: 'danger',
        category: 'RESERVOIR CUTOFF SAFETY',
        message: `Low Water Reservoir Level (${telemetry.water_level}%). Submersible pump locked out to protect impellers.`,
        action: 'Refill Storage Tank & Check Valves',
        targetTab: 'irrigation',
      });
    }
  }

  const getStatusBadge = (val: number | undefined, min: number, max: number) => {
    if (val === undefined || val === null) {
      return { text: 'WAITING', color: 'bg-slate-100 text-slate-500 border border-slate-200' };
    }
    if (val < min) {
      return { text: 'LOW DEFICIT', color: 'bg-amber-50 text-amber-700 border border-amber-200 font-bold' };
    }
    if (val > max) {
      return { text: 'HIGH WARNING', color: 'bg-rose-50 text-rose-700 border border-rose-200 font-bold' };
    }
    return { text: 'OPTIMAL', color: 'bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold' };
  };

  const tempBadge = getStatusBadge(
    telemetry?.temperature,
    cropProfile.tempRange[0],
    cropProfile.tempRange[1]
  );
  const humBadge = getStatusBadge(
    telemetry?.humidity,
    cropProfile.humRange[0],
    cropProfile.humRange[1]
  );
  const soilBadge = getStatusBadge(
    telemetry?.soil_moisture,
    pumpState.threshold,
    100
  );
  const lightBadge = getStatusBadge(telemetry?.light, 15000, 45000);
  const co2Badge = getStatusBadge(telemetry?.co2, 600, 1100);
  const tankBadge = getStatusBadge(telemetry?.water_level, 20, 100);

  return (
    <div className="space-y-6">
      {/* Hero Polyhouse Banner with Real Greenhouse Photography & Telemetry Flow */}
      <div className="relative rounded-2xl overflow-hidden shadow-md border border-emerald-900/20 bg-[#0C3823]">
        {/* Background Image with Deep Natural Green Gradient Overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=1600&q=80"
            alt="Modern Polyhouse Greenhouse"
            className="w-full h-full object-cover object-center opacity-30 mix-blend-overlay"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#072416] via-[#0C3823]/90 to-[#072416]/95" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 p-5 sm:p-6 lg:p-7 text-white space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center space-x-2">
                <span className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>SMART POLYHOUSE NODE #01 (SECTOR A)</span>
                </span>
                <span className="text-xs text-emerald-300/80 font-mono hidden sm:inline">
                  • High-Tunnel Climate Control
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-white">
                Intelligent Polyhouse Telemetry & Closed-Loop Actuation
              </h1>
              <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
                Autonomous microclimate regulation for <strong className="text-emerald-300 font-bold">{cropProfile.name}</strong> ({cropProfile.scientificName}) with real-time VPD stabilization, fertigation dosing, and automated pest alert monitoring.
              </p>
            </div>

            {/* Quick Microclimate Vital Stats Pill Overlay */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 bg-black/30 backdrop-blur-md p-3.5 rounded-xl border border-emerald-500/20 font-mono text-xs shrink-0">
              <div>
                <span className="text-[10px] text-emerald-300/80 block uppercase font-bold">Inside Temp</span>
                <span className="text-base font-black text-white">{telemetry ? `${telemetry.temperature}°C` : '--'}</span>
              </div>
              <div>
                <span className="text-[10px] text-emerald-300/80 block uppercase font-bold">Relative Hum</span>
                <span className="text-base font-black text-white">{telemetry ? `${telemetry.humidity}%` : '--'}</span>
              </div>
              <div>
                <span className="text-[10px] text-emerald-300/80 block uppercase font-bold">Target VPD</span>
                <span className="text-base font-black text-emerald-300">{cropProfile.vpdTarget}</span>
              </div>
            </div>
          </div>

          {/* IoT Pipeline Visual Flow Strip */}
          <div className="pt-3 border-t border-emerald-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-emerald-200/80">
            <div className="flex items-center space-x-1.5">
              <span className="text-white font-bold">IoT PIPELINE:</span>
              <span className="bg-[#072416] px-2 py-0.5 rounded border border-emerald-700/60 text-white">Sensors (DHT22, Soil V1.2, BH1750, CO₂)</span>
              <span>➔</span>
              <span className="bg-[#072416] px-2 py-0.5 rounded border border-emerald-700/60 text-emerald-300 font-bold">ESP32 (GPIO 4, 34, 21, 26, 27)</span>
              <span>➔</span>
              <span className="bg-[#072416] px-2 py-0.5 rounded border border-emerald-700/60 text-white">Wi-Fi REST Ingestion</span>
              <span>➔</span>
              <span className="bg-[#072416] px-2 py-0.5 rounded border border-emerald-700/60 text-emerald-300">Automated Relays</span>
            </div>
            <div className="flex items-center space-x-2 text-[10px] text-emerald-300">
              <span>STREAM: 10s INTERVAL</span>
            </div>
          </div>
        </div>
      </div>

      {/* Smart Alerts & Automated Pest Alert Banner Area */}
      {alerts.length > 0 ? (
        <div className="space-y-2.5">
          {alerts.map((alt, idx) => {
            const isDanger = alt.type === 'danger';
            const isPest = alt.type === 'pest';
            return (
              <div
                key={idx}
                className={`p-4 rounded-xl border flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 transition shadow-xs ${
                  isDanger
                    ? 'bg-rose-50 border-rose-200 text-rose-900'
                    : isPest
                    ? 'bg-amber-50 border-amber-300 text-amber-950'
                    : 'bg-amber-50/80 border-amber-200 text-amber-900'
                }`}
              >
                <div className="flex items-start space-x-3 text-xs">
                  <div
                    className={`p-2 rounded-lg shrink-0 mt-0.5 border ${
                      isDanger
                        ? 'bg-rose-100 text-rose-700 border-rose-200'
                        : isPest
                        ? 'bg-amber-100 text-amber-800 border-amber-300'
                        : 'bg-amber-100 text-amber-700 border-amber-200'
                    }`}
                  >
                    {isDanger ? (
                      <AlertCircle className="w-4 h-4" />
                    ) : isPest ? (
                      <Bug className="w-4 h-4 text-amber-800" />
                    ) : (
                      <AlertTriangle className="w-4 h-4" />
                    )}
                  </div>
                  <div className="space-y-0.5">
                    <div className="flex items-center space-x-2 font-mono">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded bg-white border border-slate-200">
                        {alt.category}
                      </span>
                    </div>
                    <p className="text-xs font-semibold leading-relaxed">{alt.message}</p>
                    <p className="text-[11px] text-slate-600 font-mono font-medium">
                      Recommended Action: <strong className="text-slate-800">{alt.action}</strong>
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => onNavigate(alt.targetTab)}
                  className={`text-xs font-bold px-3 py-1.5 rounded-lg shrink-0 flex items-center space-x-1.5 cursor-pointer uppercase font-mono tracking-wider transition shadow-xs ${
                    isDanger
                      ? 'bg-rose-600 hover:bg-rose-700 text-white'
                      : isPest
                      ? 'bg-[#0C3823] hover:bg-[#134e2e] text-white'
                      : 'bg-amber-600 hover:bg-amber-700 text-white'
                  }`}
                >
                  <span>Resolve Alert</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200 text-xs font-mono text-emerald-900 flex items-center justify-between shadow-xs">
          <div className="flex items-center space-x-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-bold">
              ALL POLYHOUSE MICROCLIMATE TELEMETRY CHANNELS ARE WITHIN OPTIMAL ICAR AGRONOMIC WINDOW.
            </span>
          </div>
          <span className="text-[10px] text-emerald-700 font-bold uppercase hidden md:inline">
            Zero Pathogen Risk Detected
          </span>
        </div>
      )}

      {/* 4 Master Control & Status Highlight Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Node Link */}
        <div
          onClick={() => onNavigate('iot-setup')}
          className="bg-white p-4 rounded-xl border border-emerald-900/10 hover:border-emerald-500 shadow-xs hover:shadow-sm transition cursor-pointer flex items-center justify-between"
        >
          <div>
            <p className="text-[10px] font-bold uppercase text-slate-500 tracking-wider font-mono">
              MICROCONTROLLER NODE
            </p>
            <p className="text-base font-black text-[#0C3823] font-mono mt-0.5">
              {telemetry?.device_id || 'POLYHOUSE_001'}
            </p>
            <p className={`text-xs font-mono font-bold mt-0.5 ${isOnline ? 'text-emerald-600' : 'text-amber-600'}`}>
              {isOnline ? '● ESP32 LINK ACTIVE' : '○ AWAITING PACKET'}
            </p>
          </div>
          <div
            className={`p-2.5 rounded-xl border ${
              isOnline
                ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                : 'bg-amber-50 text-amber-600 border-amber-200'
            }`}
          >
            <Cpu className="w-5 h-5" />
          </div>
        </div>

        {/* Card 2: Drip Irrigation */}
        <div
          onClick={() => onNavigate('irrigation')}
          className="bg-white p-4 rounded-xl border border-emerald-900/10 hover:border-blue-500 shadow-xs hover:shadow-sm transition cursor-pointer flex items-center justify-between"
        >
          <div>
            <p className="text-[10px] font-bold uppercase text-slate-500 tracking-wider font-mono">
              DRIP IRRIGATION (GPIO 26)
            </p>
            <p
              className={`text-base font-black font-mono mt-0.5 ${
                pumpState.state === 'ON' ? 'text-blue-600' : 'text-slate-700'
              }`}
            >
              RELAY 1: {pumpState.state}
            </p>
            <p className="text-xs text-slate-500 font-mono mt-0.5">
              Mode: {pumpState.mode} (&lt;{pumpState.threshold}% soil)
            </p>
          </div>
          <div
            className={`p-2.5 rounded-xl border ${
              pumpState.state === 'ON'
                ? 'bg-blue-100 text-blue-700 border-blue-300 animate-pulse'
                : 'bg-slate-100 text-slate-500 border-slate-200'
            }`}
          >
            <Droplets className="w-5 h-5" />
          </div>
        </div>

        {/* Card 3: Exhaust Ventilation */}
        <div
          onClick={() => onNavigate('ventilation')}
          className="bg-white p-4 rounded-xl border border-emerald-900/10 hover:border-amber-500 shadow-xs hover:shadow-sm transition cursor-pointer flex items-center justify-between"
        >
          <div>
            <p className="text-[10px] font-bold uppercase text-slate-500 tracking-wider font-mono">
              EXHAUST FAN (GPIO 27)
            </p>
            <p
              className={`text-base font-black font-mono mt-0.5 ${
                fanState.state === 'ON' ? 'text-amber-600' : 'text-slate-700'
              }`}
            >
              RELAY 2: {fanState.state}
            </p>
            <p className="text-xs text-slate-500 font-mono mt-0.5">
              Trigger: &gt;{fanState.threshold.toFixed(1)}°C canopy
            </p>
          </div>
          <div
            className={`p-2.5 rounded-xl border ${
              fanState.state === 'ON'
                ? 'bg-amber-100 text-amber-700 border-amber-300'
                : 'bg-slate-100 text-slate-500 border-slate-200'
            }`}
          >
            <Fan className={`w-5 h-5 ${fanState.state === 'ON' ? 'animate-spin text-amber-600' : ''}`} />
          </div>
        </div>

        {/* Card 4: Target Crop Profile */}
        <div
          onClick={() => onNavigate('crops')}
          className="bg-white p-4 rounded-xl border border-emerald-900/10 hover:border-emerald-500 shadow-xs hover:shadow-sm transition cursor-pointer flex items-center justify-between"
        >
          <div>
            <p className="text-[10px] font-bold uppercase text-slate-500 tracking-wider font-mono">
              TARGET CROP PROFILE
            </p>
            <p className="text-base font-black text-[#0C3823] font-mono mt-0.5">
              {cropProfile.name}
            </p>
            <p className="text-xs text-emerald-700 font-mono font-bold mt-0.5">
              VPD Target: {cropProfile.vpdTarget}
            </p>
          </div>
          <div className="p-2.5 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-200">
            <Trees className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Real-Time Sensor Telemetry Grid (6 Key Sensors) */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-[#0C3823] flex items-center space-x-2">
            <Activity className="w-4 h-4 text-emerald-600" />
            <span>REAL-TIME MULTI-SENSOR TELEMETRY CHANNELS</span>
          </h2>
          <span className="text-[10px] text-slate-500 font-mono">DATA BUS: JSON-REST / ESP32</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Sensor 1: Air Temperature */}
          <div className="bg-white rounded-xl border border-emerald-900/10 p-4 space-y-3 shadow-xs hover:shadow-sm transition">
            <div className="flex justify-between items-start">
              <div className="flex items-center space-x-2.5">
                <div className="p-2.5 bg-orange-50 text-orange-600 rounded-lg border border-orange-200">
                  <Thermometer className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-[#0C3823] font-mono uppercase">Air Temperature</h3>
                  <p className="text-[10px] text-slate-500 font-mono">DHT22 Digital (GPIO 4)</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${tempBadge.color}`}>
                {tempBadge.text}
              </span>
            </div>
            <div>
              <div className="flex items-baseline space-x-1.5">
                <span className="text-3xl font-black font-mono text-slate-900">
                  {telemetry ? telemetry.temperature : '--'}
                </span>
                <span className="text-slate-500 font-mono font-bold text-sm">°C</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full mt-2 overflow-hidden border border-slate-200">
                <div
                  className="bg-orange-500 h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.max(5, ((telemetry?.temperature || 0) / 45) * 100))}%`,
                  }}
                />
              </div>
            </div>
            <div className="pt-2 border-t border-slate-100 flex justify-between text-[11px] font-mono text-slate-500">
              <span>
                Optimal: <strong className="text-slate-800">{cropProfile.tempRange[0]}-{cropProfile.tempRange[1]}°C</strong>
              </span>
              <span className="text-slate-400">
                {telemetry?.timestamp
                  ? new Date(telemetry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                  : '--'}
              </span>
            </div>
          </div>

          {/* Sensor 2: Relative Humidity */}
          <div className="bg-white rounded-xl border border-emerald-900/10 p-4 space-y-3 shadow-xs hover:shadow-sm transition">
            <div className="flex justify-between items-start">
              <div className="flex items-center space-x-2.5">
                <div className="p-2.5 bg-sky-50 text-sky-600 rounded-lg border border-sky-200">
                  <CloudRain className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-[#0C3823] font-mono uppercase">Relative Humidity</h3>
                  <p className="text-[10px] text-slate-500 font-mono">DHT22 Capacitive (GPIO 4)</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${humBadge.color}`}>
                {humBadge.text}
              </span>
            </div>
            <div>
              <div className="flex items-baseline space-x-1.5">
                <span className="text-3xl font-black font-mono text-slate-900">
                  {telemetry ? telemetry.humidity : '--'}
                </span>
                <span className="text-slate-500 font-mono font-bold text-sm">%</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full mt-2 overflow-hidden border border-slate-200">
                <div
                  className="bg-sky-500 h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.max(5, telemetry?.humidity || 0))}%`,
                  }}
                />
              </div>
            </div>
            <div className="pt-2 border-t border-slate-100 flex justify-between text-[11px] font-mono text-slate-500">
              <span>
                Optimal: <strong className="text-slate-800">{cropProfile.humRange[0]}-{cropProfile.humRange[1]}%</strong>
              </span>
              <span className="text-slate-400">
                {telemetry?.timestamp
                  ? new Date(telemetry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                  : '--'}
              </span>
            </div>
          </div>

          {/* Sensor 3: Soil Moisture */}
          <div className="bg-white rounded-xl border border-emerald-900/10 p-4 space-y-3 shadow-xs hover:shadow-sm transition">
            <div className="flex justify-between items-start">
              <div className="flex items-center space-x-2.5">
                <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-lg border border-emerald-200">
                  <Sprout className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-[#0C3823] font-mono uppercase">Soil Moisture</h3>
                  <p className="text-[10px] text-slate-500 font-mono">Capacitive V1.2 (GPIO 34)</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${soilBadge.color}`}>
                {soilBadge.text}
              </span>
            </div>
            <div>
              <div className="flex items-baseline space-x-1.5">
                <span className="text-3xl font-black font-mono text-slate-900">
                  {telemetry ? telemetry.soil_moisture : '--'}
                </span>
                <span className="text-slate-500 font-mono font-bold text-sm">%</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full mt-2 overflow-hidden border border-slate-200">
                <div
                  className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.max(5, telemetry?.soil_moisture || 0))}%`,
                  }}
                />
              </div>
            </div>
            <div className="pt-2 border-t border-slate-100 flex justify-between text-[11px] font-mono text-slate-500">
              <span>
                Auto Trigger: <strong className="text-slate-800">&lt; {pumpState.threshold}%</strong>
              </span>
              <span className="text-slate-400">
                {telemetry?.timestamp
                  ? new Date(telemetry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                  : '--'}
              </span>
            </div>
          </div>

          {/* Sensor 4: Light Intensity */}
          <div className="bg-white rounded-xl border border-emerald-900/10 p-4 space-y-3 shadow-xs hover:shadow-sm transition">
            <div className="flex justify-between items-start">
              <div className="flex items-center space-x-2.5">
                <div className="p-2.5 bg-amber-50 text-amber-600 rounded-lg border border-amber-200">
                  <Sun className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-[#0C3823] font-mono uppercase">Light Intensity</h3>
                  <p className="text-[10px] text-slate-500 font-mono">BH1750 I2C (GPIO 21/22)</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${lightBadge.color}`}>
                {lightBadge.text}
              </span>
            </div>
            <div>
              <div className="flex items-baseline space-x-1.5">
                <span className="text-3xl font-black font-mono text-slate-900">
                  {telemetry ? telemetry.light.toLocaleString() : '--'}
                </span>
                <span className="text-slate-500 font-mono font-bold text-sm">lux</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full mt-2 overflow-hidden border border-slate-200">
                <div
                  className="bg-amber-500 h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.max(5, ((telemetry?.light || 0) / 45000) * 100))}%`,
                  }}
                />
              </div>
            </div>
            <div className="pt-2 border-t border-slate-100 flex justify-between text-[11px] font-mono text-slate-500">
              <span>
                PAR Target: <strong className="text-slate-800">{cropProfile.light}</strong>
              </span>
              <span className="text-slate-400">
                {telemetry?.timestamp
                  ? new Date(telemetry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                  : '--'}
              </span>
            </div>
          </div>

          {/* Sensor 5: CO2 Concentration */}
          <div className="bg-white rounded-xl border border-emerald-900/10 p-4 space-y-3 shadow-xs hover:shadow-sm transition">
            <div className="flex justify-between items-start">
              <div className="flex items-center space-x-2.5">
                <div className="p-2.5 bg-teal-50 text-teal-600 rounded-lg border border-teal-200">
                  <Wind className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-[#0C3823] font-mono uppercase">Carbon Dioxide (CO₂)</h3>
                  <p className="text-[10px] text-slate-500 font-mono">MH-Z19 Optical UART</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${co2Badge.color}`}>
                {co2Badge.text}
              </span>
            </div>
            <div>
              <div className="flex items-baseline space-x-1.5">
                <span className="text-3xl font-black font-mono text-slate-900">
                  {telemetry ? telemetry.co2 : '--'}
                </span>
                <span className="text-slate-500 font-mono font-bold text-sm">ppm</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full mt-2 overflow-hidden border border-slate-200">
                <div
                  className="bg-teal-500 h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.max(5, ((telemetry?.co2 || 0) / 1400) * 100))}%`,
                  }}
                />
              </div>
            </div>
            <div className="pt-2 border-t border-slate-100 flex justify-between text-[11px] font-mono text-slate-500">
              <span>
                Target: <strong className="text-slate-800">{cropProfile.co2}</strong>
              </span>
              <span className="text-slate-400">
                {telemetry?.timestamp
                  ? new Date(telemetry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                  : '--'}
              </span>
            </div>
          </div>

          {/* Sensor 6: Water Reservoir Level */}
          <div className="bg-white rounded-xl border border-emerald-900/10 p-4 space-y-3 shadow-xs hover:shadow-sm transition">
            <div className="flex justify-between items-start">
              <div className="flex items-center space-x-2.5">
                <div className="p-2.5 bg-cyan-50 text-cyan-600 rounded-lg border border-cyan-200">
                  <Gauge className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-[#0C3823] font-mono uppercase">Water Reservoir</h3>
                  <p className="text-[10px] text-slate-500 font-mono">HC-SR04 Ultrasonic (GPIO 18/19)</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${tankBadge.color}`}>
                {tankBadge.text}
              </span>
            </div>
            <div>
              <div className="flex items-baseline space-x-1.5">
                <span className="text-3xl font-black font-mono text-slate-900">
                  {telemetry ? telemetry.water_level : '--'}
                </span>
                <span className="text-slate-500 font-mono font-bold text-sm">%</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full mt-2 overflow-hidden border border-slate-200">
                <div
                  className="bg-cyan-500 h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.max(5, telemetry?.water_level || 0))}%`,
                  }}
                />
              </div>
            </div>
            <div className="pt-2 border-t border-slate-100 flex justify-between text-[11px] font-mono text-slate-500">
              <span>
                Safety Lockout: <strong className="text-slate-800">&gt; 20%</strong>
              </span>
              <span className="text-slate-400">
                {telemetry?.timestamp
                  ? new Date(telemetry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                  : '--'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Real-Time Environmental Stream Chart */}
      <div className="bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
          <div>
            <h3 className="text-xs font-bold text-[#0C3823] font-mono uppercase tracking-wider">
              SYNCHRONIZED ENVIRONMENTAL SLIDING STREAM
            </h3>
            <p className="text-[11px] text-slate-500">
              Live sliding telemetry window (updates dynamically on each incoming ESP32 packet)
            </p>
          </div>
          <div className="flex items-center space-x-4 text-xs font-mono">
            <span className="inline-flex items-center space-x-1.5 font-bold text-orange-600">
              <span className="w-2.5 h-2.5 rounded-full bg-orange-600" />
              <span>Air Temp (°C)</span>
            </span>
            <span className="inline-flex items-center space-x-1.5 font-bold text-sky-600">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-600" />
              <span>Humidity (%)</span>
            </span>
          </div>
        </div>
        <div className="h-64 w-full pt-2">
          <canvas ref={chartCanvasRef} />
        </div>
      </div>
    </div>
  );
};
