import React, { useState } from 'react';
import { FlaskConical, Calculator, Check, AlertCircle, Info, Sparkles } from 'lucide-react';
import { CROP_DATABASE } from '../data/crops';

interface FertilizerViewProps {
  activeCrop: string;
}

export const FertilizerView: React.FC<FertilizerViewProps> = ({ activeCrop }) => {
  const [areaSqM, setAreaSqM] = useState<number>(1000);
  const [stage, setStage] = useState<'VEGETATIVE' | 'FLOWERING' | 'HARVESTING'>('FLOWERING');
  const [crop, setCrop] = useState<string>(activeCrop || 'Tomato');

  // Multiplier formulas based on area & stage
  const areaRatio = areaSqM / 1000;
  let stageMultiplier = { n: 1.0, p: 1.0, k: 1.0, ca: 1.0, mg: 1.0 };

  if (stage === 'VEGETATIVE') {
    stageMultiplier = { n: 1.4, p: 1.2, k: 0.8, ca: 1.1, mg: 0.9 };
  } else if (stage === 'FLOWERING') {
    stageMultiplier = { n: 1.0, p: 1.5, k: 1.3, ca: 1.2, mg: 1.1 };
  } else if (stage === 'HARVESTING') {
    stageMultiplier = { n: 0.9, p: 1.1, k: 1.8, ca: 1.3, mg: 1.2 };
  }

  // Base kg/week per 1000 sq.m
  const calciumNitrateKg = +(12.5 * areaRatio * stageMultiplier.ca).toFixed(2);
  const potassiumNitrateKg = +(10.0 * areaRatio * stageMultiplier.k).toFixed(2);
  const mapKg = +(4.5 * areaRatio * stageMultiplier.p).toFixed(2);
  const sopKg = +(8.0 * areaRatio * stageMultiplier.k).toFixed(2);
  const magnesiumSulphateKg = +(5.0 * areaRatio * stageMultiplier.mg).toFixed(2);
  const ironEddhaGrams = +(120 * areaRatio).toFixed(0);
  const boronSoluborGrams = +(65 * areaRatio).toFixed(0);
  const zincEdtaGrams = +(45 * areaRatio).toFixed(0);

  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-base font-bold text-[#0C3823] font-mono uppercase tracking-wider flex items-center space-x-2">
            <FlaskConical className="w-5 h-5 text-emerald-600" />
            <span>Scientific Fertigation & Nutrient Prescription Engine</span>
          </h2>
          <p className="text-xs text-slate-600">
            Automated dosing calculations for 3-Tank AB Stock Solutions based on polyhouse surface area and phenology stage
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Input Parameters Panel */}
        <div className="lg:col-span-4 bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-4 font-mono">
          <h3 className="text-xs font-bold text-[#0C3823] uppercase tracking-wider border-b border-slate-100 pb-2">
            Polyhouse Parameters
          </h3>

          <div>
            <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1.5">
              Target Crop Selection
            </label>
            <select
              value={crop}
              onChange={(e) => setCrop(e.target.value)}
              className="w-full bg-[#f7f9f5] border border-slate-200 rounded-lg px-3 py-2.5 text-xs font-bold text-[#0C3823] outline-none focus:border-emerald-600 cursor-pointer"
            >
              {Object.keys(CROP_DATABASE).map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex justify-between text-xs font-bold mb-1">
              <span className="text-[#0C3823]">Cultivation Bed Area:</span>
              <span className="text-emerald-700">{areaSqM} m²</span>
            </div>
            <input
              type="range"
              min="200"
              max="10000"
              step="100"
              value={areaSqM}
              onChange={(e) => setAreaSqM(parseInt(e.target.value, 10))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#0C3823]"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>200 m²</span>
              <span>1,000 m²</span>
              <span>10,000 m² (1 Ha)</span>
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1.5">
              Phenological Stage
            </label>
            <div className="space-y-2">
              {[
                { id: 'VEGETATIVE', label: 'Vegetative & Canopy Expansion', desc: 'High Nitrogen (N) focus' },
                { id: 'FLOWERING', label: 'Flowering & Fruit Induction', desc: 'High Phosphorus (P) focus' },
                { id: 'HARVESTING', label: 'Fruit Sizing & Harvest', desc: 'High Potassium (K) focus' },
              ].map((stg) => (
                <button
                  key={stg.id}
                  onClick={() => setStage(stg.id as any)}
                  className={`w-full text-left p-3 rounded-xl border transition cursor-pointer ${
                    stage === stg.id
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 shadow-xs'
                      : 'border-slate-200 bg-[#f7f9f5] text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <p className="text-xs font-bold font-mono">{stg.label}</p>
                  <p className="text-[11px] text-slate-500 font-sans mt-0.5">{stg.desc}</p>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Prescription Dosage Table */}
        <div className="lg:col-span-8 bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-4 font-mono">
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-xs font-bold text-[#0C3823] uppercase tracking-wider">
                Weekly Fertigation Schedule ({crop} - {areaSqM} m²)
              </h3>
              <p className="text-[11px] text-slate-500 font-sans">
                Calculated for daily pulse fertigation (divide weekly totals by 6 feeding days)
              </p>
            </div>
            <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-lg border border-emerald-300 uppercase">
              STAGE: {stage}
            </span>
          </div>

          {/* Dosing Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            {/* Tank A */}
            <div className="p-4 rounded-xl border border-emerald-200 bg-[#f7f9f5] space-y-3">
              <div className="flex justify-between items-center">
                <h4 className="text-[11px] font-bold text-[#0C3823] uppercase">Stock Tank A</h4>
                <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded border border-emerald-200">
                  Calcium + Iron
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-600">Calcium Nitrate:</span>
                  <span className="font-bold text-[#0C3823]">{calciumNitrateKg} kg</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-600">Potassium Nitrate:</span>
                  <span className="font-bold text-[#0C3823]">{potassiumNitrateKg} kg</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Iron EDDHA:</span>
                  <span className="font-bold text-emerald-700">{ironEddhaGrams} g</span>
                </div>
              </div>
            </div>

            {/* Tank B */}
            <div className="p-4 rounded-xl border border-emerald-200 bg-[#f7f9f5] space-y-3">
              <div className="flex justify-between items-center">
                <h4 className="text-[11px] font-bold text-[#0C3823] uppercase">Stock Tank B</h4>
                <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded border border-emerald-200">
                  P + K + Mg
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-600">MAP (12-61-0):</span>
                  <span className="font-bold text-[#0C3823]">{mapKg} kg</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-600">SOP (0-0-50):</span>
                  <span className="font-bold text-[#0C3823]">{sopKg} kg</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Mag Sulphate:</span>
                  <span className="font-bold text-emerald-700">{magnesiumSulphateKg} kg</span>
                </div>
              </div>
            </div>

            {/* Tank C / Trace */}
            <div className="p-4 rounded-xl border border-emerald-200 bg-[#f7f9f5] space-y-3">
              <div className="flex justify-between items-center">
                <h4 className="text-[11px] font-bold text-[#0C3823] uppercase">Tank C / Micro</h4>
                <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded border border-emerald-200">
                  Trace Minerals
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-600">Boron (Solubor):</span>
                  <span className="font-bold text-[#0C3823]">{boronSoluborGrams} g</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-600">Zinc-EDTA:</span>
                  <span className="font-bold text-[#0C3823]">{zincEdtaGrams} g</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Target pH:</span>
                  <span className="font-bold text-emerald-700">5.8 - 6.2</span>
                </div>
              </div>
            </div>
          </div>

          {/* Compatibility Safety Warning Banner */}
          <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-start space-x-2.5">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-0.5 text-[11px]">
              <strong className="font-bold block text-amber-900 font-mono">
                Crucial Chemical Compatibility Rule:
              </strong>
              <p className="leading-relaxed text-amber-800 font-sans">
                <strong>NEVER</strong> mix Calcium Nitrate with Phosphates (MAP) or Sulphates in the same concentrated stock tank. Calcium will bond with Sulphate/Phosphate to form insoluble Calcium Sulphate (Gypsum) precipitate, immediately clogging drip emitters.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
