import React from 'react';
import {
  Sprout,
  Radio,
  Flower2,
  LayoutDashboard,
  Cpu,
  BarChart3,
  Droplets,
  Fan,
  Trees,
  ScanLine,
  FlaskConical,
  CloudSun,
  Calculator,
  Terminal,
  Activity,
} from 'lucide-react';
import { ViewTab } from '../types';

interface HeaderProps {
  currentTab: ViewTab;
  onSelectTab: (tab: ViewTab) => void;
  systemMode: 'LIVE' | 'DEMO';
  onToggleMode: () => void;
  isOnline: boolean;
  activeCrop: string;
  onChangeCrop: (crop: string) => void;
  cropList: string[];
  lastHeartbeatTime: number | null;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  systemMode,
  onToggleMode,
  isOnline,
  activeCrop,
  onChangeCrop,
  cropList,
  lastHeartbeatTime,
}) => {
  const tabs: { id: ViewTab; label: string; icon: React.ElementType }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'sensors', label: 'Sensors', icon: Cpu },
    { id: 'history', label: 'Analytics', icon: BarChart3 },
    { id: 'irrigation', label: 'Irrigation', icon: Droplets },
    { id: 'ventilation', label: 'Ventilation', icon: Fan },
    { id: 'crops', label: 'Crops', icon: Trees },
    { id: 'ai-scanner', label: 'AI Scanner', icon: ScanLine },
    { id: 'fertilizer', label: 'Fertilizer', icon: FlaskConical },
    { id: 'weather', label: 'Weather', icon: CloudSun },
    { id: 'calculator', label: 'Economics', icon: Calculator },
    { id: 'iot-setup', label: 'ESP32 Setup', icon: Terminal },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0C3823] border-b border-[#14532d] shadow-md text-white">
      {/* Top Status & Telemetry Bar */}
      <div className="text-xs px-4 py-1.5 border-b border-[#134e2e] bg-[#072416] flex flex-wrap justify-between items-center gap-2">
        <div className="flex items-center space-x-3">
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                systemMode === 'LIVE'
                  ? isOnline
                    ? 'bg-emerald-400 shadow-[0_0_8px_#34d399] animate-pulse'
                    : 'bg-rose-500 shadow-[0_0_8px_#f43f5e] animate-pulse'
                  : 'bg-amber-400 shadow-[0_0_8px_#fbbf24] animate-pulse'
              }`}
            />
            <span className="font-mono text-[11px] font-bold tracking-tight">
              {systemMode === 'LIVE' ? (
                isOnline ? (
                  <span className="text-emerald-300 font-semibold">🟢 ESP32 ONLINE (LIVE STREAM)</span>
                ) : (
                  <span className="text-rose-300 font-semibold">🔴 ESP32 OFFLINE (AWAITING LINK)</span>
                )
              ) : (
                <span className="text-amber-300 font-semibold">🟠 DEMO SIMULATION ACTIVE</span>
              )}
            </span>
          </div>
          <span className="text-emerald-800">|</span>
          <span className="text-[10px] text-emerald-200/80 font-mono tracking-wider uppercase hidden md:inline">
            Node: <span className="text-white font-bold">PH_001_A</span> (ESP32-WROOM-32D)
          </span>
          <span className="text-emerald-800 hidden md:inline">|</span>
          <span className="text-[10px] text-emerald-200/80 font-mono hidden lg:inline">
            INGEST: <code className="text-emerald-200 bg-[#0c3823] px-1.5 py-0.5 rounded border border-[#14532d]">/api/iot/readings</code>
          </span>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="hidden sm:flex items-center gap-3 text-[11px] text-emerald-200/80">
            <span>UPTIME: <span className="text-white font-bold">142:12:04</span></span>
            <span>SIGNAL: <span className="text-white font-bold">{isOnline ? '-64 dBm' : 'LOST'}</span></span>
          </div>
          <span className="text-emerald-800 hidden sm:inline">|</span>
          <button
            onClick={onToggleMode}
            className={`px-2.5 py-1 rounded text-[10px] font-bold font-sans uppercase tracking-wider transition border cursor-pointer ${
              systemMode === 'LIVE'
                ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30'
                : 'bg-amber-500/20 border-amber-400/40 text-amber-200 hover:bg-amber-500/30'
            }`}
          >
            {systemMode === 'LIVE' ? 'Switch to Demo Sim' : 'Switch to Live ESP32'}
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between h-14 items-center gap-4">
        {/* Brand Logo */}
        <div
          className="flex items-center space-x-3 cursor-pointer group shrink-0"
          onClick={() => onSelectTab('dashboard')}
        >
          <div className="w-9 h-9 bg-emerald-500 text-[#072416] rounded-lg flex items-center justify-center font-black text-lg shadow-sm group-hover:scale-105 transition">
            <Sprout className="w-5 h-5 text-[#072416]" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center space-x-1.5">
              <span className="text-white font-black text-base tracking-tight leading-none">
                AGROPOLY <span className="text-emerald-400">SMART</span>
              </span>
              <span className="px-1.5 py-0.2 bg-[#072416] text-emerald-300 text-[9px] font-mono font-bold rounded border border-emerald-700/60">
                v2.4
              </span>
            </div>
            <span className="text-[10px] text-emerald-200/70 font-mono tracking-widest uppercase mt-0.5">
              Smart Polyhouse Farming & IoT
            </span>
          </div>
        </div>

        {/* Desktop Navigation Tabs */}
        <nav className="hidden xl:flex items-center space-x-1 overflow-x-auto">
          {tabs.map((t) => {
            const Icon = t.icon;
            const active = currentTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => onSelectTab(t.id)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition flex items-center space-x-1.5 cursor-pointer uppercase tracking-tight ${
                  active
                    ? 'bg-white/15 text-white border border-emerald-400/40 shadow-xs backdrop-blur-xs font-bold'
                    : 'text-emerald-100/80 hover:text-white hover:bg-white/10 border border-transparent'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${active ? 'text-emerald-300' : 'text-emerald-300/70'}`} />
                <span>{t.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Active Polyhouse Crop Selector */}
        <div className="flex items-center space-x-2 bg-[#072416] px-3 py-1.5 rounded-lg border border-emerald-800/80 shrink-0">
          <Flower2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <div className="flex flex-col">
            <span className="text-[8px] uppercase font-bold text-emerald-300/70 leading-none">Active Crop</span>
            <select
              value={activeCrop}
              onChange={(e) => onChangeCrop(e.target.value)}
              className="bg-transparent text-xs font-bold text-white font-mono outline-none cursor-pointer pr-1"
            >
              {cropList.map((crop) => (
                <option key={crop} value={crop} className="bg-[#0C3823] text-white">
                  {crop}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Horizontal Scrollable Tabs on Smaller Screens */}
      <div className="xl:hidden flex overflow-x-auto space-x-1 px-4 py-2 border-t border-[#134e2e] bg-[#072416]/95 custom-scroll">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = currentTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => onSelectTab(t.id)}
              className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 shrink-0 cursor-pointer uppercase ${
                active
                  ? 'bg-white/20 text-white border border-emerald-400/40 font-bold'
                  : 'text-emerald-100/80 hover:text-white hover:bg-white/10'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${active ? 'text-emerald-300' : 'text-emerald-300/70'}`} />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
