import React, { useState, useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';
import { TelemetryPacket, CropProfile } from '../types';

Chart.register(...registerables);

interface HistoricalAnalyticsViewProps {
  history: TelemetryPacket[];
  cropProfile: CropProfile;
}

export const HistoricalAnalyticsView: React.FC<HistoricalAnalyticsViewProps> = ({
  history,
  cropProfile,
}) => {
  const [timeframe, setTimeframe] = useState<'1h' | '24h' | '7d' | '30d'>('24h');

  const chartTempHumRef = useRef<HTMLCanvasElement | null>(null);
  const chartSoilRef = useRef<HTMLCanvasElement | null>(null);

  const instanceTempHum = useRef<Chart | null>(null);
  const instanceSoil = useRef<Chart | null>(null);

  // Compute aggregate statistical metrics
  const temps = history.map((p) => p.temperature);
  const hums = history.map((p) => p.humidity);
  const soils = history.map((p) => p.soil_moisture);
  const co2s = history.map((p) => p.co2);
  const lights = history.map((p) => p.light);

  const meanTemp = temps.length ? (temps.reduce((a, b) => a + b, 0) / temps.length).toFixed(1) : '25.8';
  const minTemp = temps.length ? Math.min(...temps).toFixed(1) : '18.2';
  const maxTemp = temps.length ? Math.max(...temps).toFixed(1) : '31.4';

  const meanHum = hums.length ? (hums.reduce((a, b) => a + b, 0) / hums.length).toFixed(0) : '68';
  const minHum = hums.length ? Math.min(...hums).toFixed(0) : '48';
  const maxHum = hums.length ? Math.max(...hums).toFixed(0) : '84';

  const meanSoil = soils.length ? (soils.reduce((a, b) => a + b, 0) / soils.length).toFixed(0) : '62';
  const peakLight = lights.length ? (Math.max(...lights) / 1000).toFixed(1) : '34.5';
  const meanCo2 = co2s.length ? (co2s.reduce((a, b) => a + b, 0) / co2s.length).toFixed(0) : '680';

  useEffect(() => {
    // Generate data depending on timeframe
    let labels: string[] = [];
    let tempSeries: number[] = [];
    let humSeries: number[] = [];
    let soilSeries: number[] = [];
    let waterVolumeSeries: number[] = [];

    if (timeframe === '1h') {
      labels = ['10:00', '10:10', '10:20', '10:30', '10:40', '10:50', '11:00'];
      tempSeries = [24.5, 25.1, 26.0, 26.8, 27.4, 27.9, 28.2];
      humSeries = [74, 72, 69, 66, 64, 63, 62];
      soilSeries = [64, 62, 60, 58, 72, 70, 68];
      waterVolumeSeries = [0, 0, 0, 0, 85, 0, 0];
    } else if (timeframe === '24h') {
      labels = ['00:00', '03:00', '06:00', '09:00', '12:00', '15:00', '18:00', '21:00'];
      tempSeries = [19.2, 18.0, 19.8, 24.5, 30.1, 28.7, 24.2, 21.5];
      humSeries = [84, 88, 82, 68, 52, 56, 69, 78];
      soilSeries = [68, 65, 62, 57, 49, 74, 70, 66];
      waterVolumeSeries = [0, 0, 0, 0, 120, 0, 0, 0];
    } else if (timeframe === '7d') {
      labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      tempSeries = [25.2, 26.1, 24.8, 27.3, 25.9, 26.5, 25.4];
      humSeries = [67, 64, 71, 59, 68, 66, 70];
      soilSeries = [66, 58, 72, 61, 52, 70, 64];
      waterVolumeSeries = [140, 0, 180, 0, 190, 0, 160];
    } else {
      labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
      tempSeries = [24.8, 25.6, 26.2, 25.4];
      humSeries = [68, 65, 63, 67];
      soilSeries = [62, 64, 61, 63];
      waterVolumeSeries = [840, 910, 880, 930];
    }

    // Render Diurnal Chart
    if (chartTempHumRef.current) {
      const ctx1 = chartTempHumRef.current.getContext('2d');
      if (ctx1) {
        if (instanceTempHum.current) {
          instanceTempHum.current.destroy();
        }
        instanceTempHum.current = new Chart(ctx1, {
          type: 'line',
          data: {
            labels,
            datasets: [
              {
                label: 'Air Temp (°C)',
                data: tempSeries,
                borderColor: '#f97316',
                backgroundColor: 'rgba(249, 115, 22, 0.1)',
                fill: true,
                tension: 0.35,
                borderWidth: 2,
              },
              {
                label: 'Relative Humidity (%)',
                data: humSeries,
                borderColor: '#38bdf8',
                backgroundColor: 'rgba(56, 189, 248, 0.1)',
                fill: true,
                tension: 0.35,
                borderWidth: 2,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'top',
                labels: {
                  color: '#94A3B8',
                  font: { family: 'ui-monospace, monospace', size: 10, weight: 'bold' },
                },
              },
              tooltip: {
                backgroundColor: '#0F172A',
                titleColor: '#F8FAFC',
                bodyColor: '#94A3B8',
                borderColor: '#334155',
                borderWidth: 1,
              },
            },
            scales: {
              y: {
                grid: { color: '#334155' },
                ticks: { color: '#94A3B8', font: { family: 'ui-monospace, monospace', size: 10 } },
              },
              x: {
                grid: { color: '#334155' },
                ticks: { color: '#94A3B8', font: { family: 'ui-monospace, monospace', size: 10 } },
              },
            },
          },
        });
      }
    }

    // Render Soil Chart
    if (chartSoilRef.current) {
      const ctx2 = chartSoilRef.current.getContext('2d');
      if (ctx2) {
        if (instanceSoil.current) {
          instanceSoil.current.destroy();
        }
        instanceSoil.current = new Chart(ctx2, {
          type: 'bar',
          data: {
            labels,
            datasets: [
              {
                type: 'line',
                label: 'Soil Moisture (%)',
                data: soilSeries,
                borderColor: '#10b981',
                backgroundColor: 'transparent',
                borderWidth: 2.5,
                yAxisID: 'ySoil',
                tension: 0.3,
              },
              {
                type: 'bar',
                label: 'Irrigation Volume (Liters)',
                data: waterVolumeSeries,
                backgroundColor: 'rgba(56, 189, 248, 0.65)',
                borderRadius: 4,
                yAxisID: 'yWater',
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'top',
                labels: {
                  color: '#94A3B8',
                  font: { family: 'ui-monospace, monospace', size: 10, weight: 'bold' },
                },
              },
              tooltip: {
                backgroundColor: '#0F172A',
                titleColor: '#F8FAFC',
                bodyColor: '#94A3B8',
                borderColor: '#334155',
                borderWidth: 1,
              },
            },
            scales: {
              ySoil: {
                type: 'linear',
                position: 'left',
                min: 0,
                max: 100,
                ticks: {
                  color: '#94A3B8',
                  font: { family: 'ui-monospace, monospace', size: 10 },
                  callback: (v) => `${v}%`,
                },
                grid: { color: '#334155' },
              },
              yWater: {
                type: 'linear',
                position: 'right',
                grid: { display: false },
                ticks: {
                  color: '#94A3B8',
                  font: { family: 'ui-monospace, monospace', size: 10 },
                  callback: (v) => `${v}L`,
                },
              },
              x: {
                grid: { color: '#334155' },
                ticks: { color: '#94A3B8', font: { family: 'ui-monospace, monospace', size: 10 } },
              },
            },
          },
        });
      }
    }

    return () => {
      if (instanceTempHum.current) instanceTempHum.current.destroy();
      if (instanceSoil.current) instanceSoil.current.destroy();
    };
  }, [timeframe]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <h2 className="text-base font-bold text-white font-mono uppercase tracking-wider">
            Historical Agronomic Analytics
          </h2>
          <p className="text-xs text-slate-400 font-mono">
            Analyze microclimate trajectories, diurnal extremes, Daily Light Integral (DLI), and soil replenishment efficiency
          </p>
        </div>
        <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs font-mono">
          {(['1h', '24h', '7d', '30d'] as const).map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1 rounded-md font-bold transition cursor-pointer ${
                timeframe === tf
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {tf === '1h' ? '1H' : tf === '24h' ? '24H' : tf === '7d' ? '7D' : '30D'}
            </button>
          ))}
        </div>
      </div>

      {/* Aggregate Statistical Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-center font-mono">
        <div className="bg-[#1E293B] p-3 rounded-lg border border-slate-800">
          <p className="text-[10px] font-bold uppercase text-slate-400">Mean Temp</p>
          <p className="text-base font-bold text-white mt-0.5">{meanTemp} °C</p>
          <p className="text-[10px] text-slate-500">Min: {minTemp} | Max: {maxTemp}</p>
        </div>

        <div className="bg-[#1E293B] p-3 rounded-lg border border-slate-800">
          <p className="text-[10px] font-bold uppercase text-slate-400">Mean Humidity</p>
          <p className="text-base font-bold text-white mt-0.5">{meanHum} %</p>
          <p className="text-[10px] text-slate-500">Min: {minHum}% | Max: {maxHum}%</p>
        </div>

        <div className="bg-[#1E293B] p-3 rounded-lg border border-slate-800">
          <p className="text-[10px] font-bold uppercase text-slate-400">Mean Soil Moisture</p>
          <p className="text-base font-bold text-white mt-0.5">{meanSoil} %</p>
          <p className="text-[10px] text-emerald-400">Target &gt; {cropProfile.soilTarget}%</p>
        </div>

        <div className="bg-[#1E293B] p-3 rounded-lg border border-slate-800">
          <p className="text-[10px] font-bold uppercase text-slate-400">Peak Light</p>
          <p className="text-base font-bold text-white mt-0.5">{peakLight}k lux</p>
          <p className="text-[10px] text-slate-500">DLI: 15.8 mol/m²/d</p>
        </div>

        <div className="bg-[#1E293B] p-3 rounded-lg border border-slate-800">
          <p className="text-[10px] font-bold uppercase text-slate-400">Mean CO₂ Target</p>
          <p className="text-base font-bold text-white mt-0.5">{meanCo2} ppm</p>
          <p className="text-[10px] text-purple-400">Optimal</p>
        </div>

        <div className="bg-[#1E293B] p-3 rounded-lg border border-slate-800">
          <p className="text-[10px] font-bold uppercase text-slate-400">Irrigation Cycles</p>
          <p className="text-base font-bold text-white mt-0.5">5 Runs</p>
          <p className="text-[10px] text-sky-400">~210 L Total</p>
        </div>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-[#1E293B] p-4 rounded-lg border border-slate-800 space-y-3">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
            Diurnal Temperature & Humidity Trajectory
          </h3>
          <div className="h-64 w-full">
            <canvas ref={chartTempHumRef} />
          </div>
        </div>

        <div className="bg-[#1E293B] p-4 rounded-lg border border-slate-800 space-y-3">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
            Soil Moisture Depletion vs Irrigation Runs
          </h3>
          <div className="h-64 w-full">
            <canvas ref={chartSoilRef} />
          </div>
        </div>
      </div>
    </div>
  );
};
