import React, { useState } from 'react';
import {
  Terminal,
  Cpu,
  Code2,
  Copy,
  Check,
  Send,
  Radio,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Layers,
} from 'lucide-react';

interface IotSetupViewProps {
  onSendTestPacket: (packet: any) => Promise<void>;
  isOnline: boolean;
}

export const IotSetupView: React.FC<IotSetupViewProps> = ({
  onSendTestPacket,
  isOnline,
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [testTemp, setTestTemp] = useState<number>(27.4);
  const [testHum, setTestHum] = useState<number>(68);
  const [testSoil, setTestSoil] = useState<number>(46);
  const [testLight, setTestLight] = useState<number>(28500);
  const [testCo2, setTestCo2] = useState<number>(750);
  const [testTank, setTestTank] = useState<number>(82);
  const [testStatus, setTestStatus] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);

  const sampleArduinoCode = `/*
 * AgroPoly Smart - ESP32 Complete Microcontroller Firmware
 * REST API Ingestion to /api/iot/readings
 */
#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>
#include <Wire.h>
#include <BH1750.h>

const char* ssid = "YOUR_FARM_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
const char* serverUrl = "https://your-agropoly-domain.run.app/api/iot/readings";

#define DHTPIN 4
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);
BH1750 lightMeter;

#define SOIL_PIN 34
#define RELAY_PUMP_PIN 26
#define RELAY_FAN_PIN 27
#define TRIG_PIN 18
#define ECHO_PIN 19

void setup() {
  Serial.begin(115200);
  pinMode(RELAY_PUMP_PIN, OUTPUT);
  pinMode(RELAY_FAN_PIN, OUTPUT);
  digitalWrite(RELAY_PUMP_PIN, HIGH); // Active LOW relay off
  digitalWrite(RELAY_FAN_PIN, HIGH);

  dht.begin();
  Wire.begin(21, 22);
  lightMeter.begin();

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\\nWiFi Connected!");
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(serverUrl);
    http.addHeader("Content-Type", "application/json");

    float t = dht.readTemperature();
    float h = dht.readHumidity();
    int soilRaw = analogRead(SOIL_PIN);
    float soilMoisture = map(soilRaw, 3200, 1400, 0, 100);
    float lux = lightMeter.readLightLevel();

    String jsonPayload = "{\\"device_id\\":\\"POLYHOUSE_001\\",\\"temperature\\":" + String(t, 1) +
                         ",\\"humidity\\":" + String(h, 0) +
                         ",\\"soil_moisture\\":" + String(soilMoisture, 0) +
                         ",\\"light\\":" + String(lux, 0) +
                         ",\\"co2\\":720,\\"water_level\\":85}";

    int httpResponseCode = http.POST(jsonPayload);
    Serial.printf("POST Code: %d\\n", httpResponseCode);
    http.end();
  }
  delay(10000); // 10 second telemetry cycle
}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(sampleArduinoCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 3000);
  };

  const handleSendTestPayload = async () => {
    setIsSending(true);
    setTestStatus('Transmitting test JSON telemetry to /api/iot/readings...');
    try {
      await onSendTestPacket({
        device_id: 'POLYHOUSE_001',
        temperature: Number(testTemp),
        humidity: Number(testHum),
        soil_moisture: Number(testSoil),
        light: Number(testLight),
        co2: Number(testCo2),
        water_level: Number(testTank),
        timestamp: new Date().toISOString(),
      });
      setTestStatus('✓ Packet successfully ingested! Check Dashboard and Analytics.');
    } catch (e: any) {
      setTestStatus(`Error: ${e.message}`);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <h2 className="text-base font-bold text-[#0C3823] font-mono uppercase tracking-wider flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-emerald-600" />
            <span>ESP32 Microcontroller Integration & Hardware Setup</span>
          </h2>
          <p className="text-xs text-slate-600">
            3-Step guide to wire, flash, and transmit field sensor packets to the AgroPoly cloud telemetry stream
          </p>
        </div>
        <div className="flex items-center space-x-2 font-mono">
          <span
            className={`px-3 py-1.5 rounded-full text-xs font-bold flex items-center space-x-1.5 border shadow-xs ${
              isOnline
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                : 'bg-amber-50 text-amber-800 border-amber-300'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>{isOnline ? 'ESP32 Stream Active' : 'Awaiting Hardware Packet'}</span>
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 font-mono">
        {/* Step 1 & 2: Hardware wiring & Code */}
        <div className="lg:col-span-7 space-y-4">
          {/* Step 1: Pinout */}
          <div className="bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-4">
            <h3 className="text-xs font-bold text-[#0C3823] uppercase tracking-wider flex items-center space-x-2">
              <span className="w-5 h-5 rounded-full bg-[#0C3823] text-white flex items-center justify-center text-[10px]">
                1
              </span>
              <span>Hardware Pinout & GPIO Allocation</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-[#f7f9f5] rounded-xl border border-slate-200 space-y-1">
                <strong className="text-[#0C3823] font-bold block text-xs">DHT22 Temp & Humidity</strong>
                <span className="font-mono text-emerald-700 font-bold text-[11px]">GPIO 4</span>
                <p className="text-[10px] text-slate-500 font-sans">Digital 1-Wire with 10kΩ pull-up to 3.3V</p>
              </div>

              <div className="p-3 bg-[#f7f9f5] rounded-xl border border-slate-200 space-y-1">
                <strong className="text-[#0C3823] font-bold block text-xs">Capacitive Soil Moisture</strong>
                <span className="font-mono text-emerald-700 font-bold text-[11px]">GPIO 34 (ADC1)</span>
                <p className="text-[10px] text-slate-500 font-sans">Analog input (Calibrated 1400-3200 ADC)</p>
              </div>

              <div className="p-3 bg-[#f7f9f5] rounded-xl border border-slate-200 space-y-1">
                <strong className="text-[#0C3823] font-bold block text-xs">BH1750 Ambient Light</strong>
                <span className="font-mono text-emerald-700 font-bold text-[11px]">GPIO 21 (SDA) / 22 (SCL)</span>
                <p className="text-[10px] text-slate-500 font-sans">Standard I2C Bus @ 400kHz</p>
              </div>

              <div className="p-3 bg-[#f7f9f5] rounded-xl border border-slate-200 space-y-1">
                <strong className="text-[#0C3823] font-bold block text-xs">Dual 5V Opto-Relays</strong>
                <span className="font-mono text-emerald-700 font-bold text-[11px]">GPIO 26 (Pump) / 27 (Fan)</span>
                <p className="text-[10px] text-slate-500 font-sans">Isolated 10A 250VAC switching contacts</p>
              </div>
            </div>
          </div>

          {/* Step 2: C++ Firmware */}
          <div className="bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-3">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-bold text-[#0C3823] uppercase tracking-wider flex items-center space-x-2">
                <span className="w-5 h-5 rounded-full bg-[#0C3823] text-white flex items-center justify-center text-[10px]">
                  2
                </span>
                <span>ESP32 C++ Firmware Sketch</span>
              </h3>
              <button
                onClick={handleCopy}
                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg text-xs font-bold text-emerald-900 flex items-center space-x-1.5 transition cursor-pointer"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5 text-emerald-700" />}
                <span>{copiedCode ? 'Copied' : 'Copy Sketch'}</span>
              </button>
            </div>

            <pre className="bg-slate-900 text-emerald-300 p-4 rounded-xl text-[11px] font-mono overflow-x-auto max-h-64 border border-slate-800">
              <code>{sampleArduinoCode}</code>
            </pre>
          </div>
        </div>

        {/* Step 3: Interactive REST API Test Transmitter */}
        <div className="lg:col-span-5 bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-[#0C3823] uppercase tracking-wider flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="w-5 h-5 rounded-full bg-[#0C3823] text-white flex items-center justify-center text-[10px]">
                3
              </span>
              <span>REST API Live Packet Transmitter</span>
            </h3>

            <p className="text-xs text-slate-600 font-sans">
              Send a test JSON telemetry packet directly to <code className="bg-slate-100 text-emerald-800 font-mono px-1.5 py-0.5 rounded border border-slate-200 text-[11px]">POST /api/iot/readings</code>.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span className="text-slate-700">Temperature (°C):</span>
                  <span className="text-orange-700 font-mono">{testTemp} °C</span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="42"
                  step="0.1"
                  value={testTemp}
                  onChange={(e) => setTestTemp(parseFloat(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded appearance-none cursor-pointer accent-orange-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span className="text-slate-700">Humidity (%):</span>
                  <span className="text-blue-700 font-mono">{testHum} %</span>
                </div>
                <input
                  type="range"
                  min="30"
                  max="95"
                  value={testHum}
                  onChange={(e) => setTestHum(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded appearance-none cursor-pointer accent-blue-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span className="text-slate-700">Soil Moisture (%):</span>
                  <span className="text-emerald-700 font-mono">{testSoil} %</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="90"
                  value={testSoil}
                  onChange={(e) => setTestSoil(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded appearance-none cursor-pointer accent-emerald-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span className="text-slate-700">Light (lux):</span>
                  <span className="text-amber-700 font-mono">{testLight.toLocaleString()} lux</span>
                </div>
                <input
                  type="range"
                  min="2000"
                  max="45000"
                  step="500"
                  value={testLight}
                  onChange={(e) => setTestLight(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded appearance-none cursor-pointer accent-amber-600"
                />
              </div>
            </div>

            <button
              onClick={handleSendTestPayload}
              disabled={isSending}
              className="w-full py-2.5 px-4 rounded-xl font-bold text-xs bg-[#0C3823] hover:bg-[#082618] text-white flex items-center justify-center space-x-2 transition cursor-pointer shadow-xs"
            >
              <Send className={`w-3.5 h-3.5 ${isSending ? 'animate-bounce' : ''}`} />
              <span>{isSending ? 'Transmitting Ingestion Packet...' : 'Transmit Test Telemetry Packet'}</span>
            </button>

            {testStatus && (
              <div
                className={`p-3 rounded-xl text-xs font-mono flex items-center space-x-2 ${
                  testStatus.startsWith('✓')
                    ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                    : 'bg-slate-100 text-slate-800 border border-slate-200'
                }`}
              >
                {testStatus.startsWith('✓') ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                ) : (
                  <Terminal className="w-4 h-4 text-slate-600 shrink-0" />
                )}
                <span>{testStatus}</span>
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-100 text-[10px] text-slate-500 font-sans">
            HTTPS Endpoints secured with standard JSON REST serialization
          </div>
        </div>
      </div>
    </div>
  );
};
