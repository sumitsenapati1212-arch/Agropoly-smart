import React from 'react';
import {
  Droplets,
  ShieldCheck,
  Cpu,
  Sliders,
  Play,
  Square,
  History,
  Info,
  AlertTriangle,
} from 'lucide-react';
import { ActuatorState, IrrigationLogEntry, TelemetryPacket } from '../types';

interface IrrigationViewProps {
  pumpState: ActuatorState;
  telemetry: TelemetryPacket | null;
  onSetPumpMode: (mode: 'AUTO' | 'MANUAL') => void;
  onSetThreshold: (val: number) => void;
  onRequestAction: (action: 'PUMP_START' | 'PUMP_STOP') => void;
  logs: IrrigationLogEntry[];
}

export const IrrigationView: React.FC<IrrigationViewProps> = ({
  pumpState,
  telemetry,
  onSetPumpMode,
  onSetThreshold,
  onRequestAction,
  logs,
}) => {
  const isTankLow = telemetry ? telemetry.water_level < 20 : false;

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <h2 className="text-base font-bold text-[#0C3823] font-mono uppercase tracking-wider flex items-center space-x-2">
            <Droplets className="w-5 h-5 text-emerald-600" />
            <span>Precision Irrigation & Drip Controller</span>
          </h2>
          <p className="text-xs text-slate-600">
            Automated moisture-triggered drip relay interfaced with ESP32 (GPIO 26) with reservoir interlocks
          </p>
        </div>
        <div className="flex items-center space-x-2 bg-emerald-50 text-emerald-800 px-3 py-1.5 rounded-lg text-xs font-mono font-bold border border-emerald-200">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Low Water Tank Cutoff Active (20%)</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Controls & Setpoint Panel */}
        <div className="lg:col-span-6 bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-200">
                <Droplets className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#0C3823] uppercase font-mono">Sub-Surface Drip Pump Relay</h3>
                <p className="text-[11px] text-slate-500 font-mono">ESP32 Pin: GPIO 26 | Relay Channel 1</p>
              </div>
            </div>
            <span
              className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase border font-mono ${
                pumpState.state === 'ON'
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300 animate-pulse'
                  : 'bg-slate-100 text-slate-600 border-slate-200'
              }`}
            >
              {pumpState.state === 'ON' ? 'RUNNING (ACTIVE)' : 'STANDBY (OFF)'}
            </span>
          </div>

          {/* Automatic Trigger Setpoint Slider */}
          <div className="p-4 bg-[#f7f9f5] rounded-xl border border-emerald-900/10 space-y-2">
            <div className="flex justify-between text-xs font-bold font-mono">
              <span className="text-[#0C3823]">Automatic Irrigation Trigger:</span>
              <span className="text-emerald-700">Soil Moisture &lt; {pumpState.threshold}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="80"
              value={pumpState.threshold}
              onChange={(e) => onSetThreshold(parseInt(e.target.value, 10))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#0C3823]"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>20% (Dry Stress)</span>
              <span>50% (Default Setpoint)</span>
              <span>80% (Field Saturation)</span>
            </div>
          </div>

          {/* Mode Selector */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => onSetPumpMode('AUTO')}
              className={`py-2.5 px-3 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer font-mono ${
                pumpState.mode === 'AUTO'
                  ? 'border border-emerald-600 bg-emerald-50 text-emerald-800 shadow-xs'
                  : 'border border-slate-200 bg-[#f7f9f5] text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>AUTO SMART MODE</span>
            </button>
            <button
              onClick={() => onSetPumpMode('MANUAL')}
              className={`py-2.5 px-3 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer font-mono ${
                pumpState.mode === 'MANUAL'
                  ? 'border border-emerald-600 bg-emerald-50 text-emerald-800 shadow-xs'
                  : 'border border-slate-200 bg-[#f7f9f5] text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>MANUAL OVERRIDE</span>
            </button>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              onClick={() => onRequestAction('PUMP_START')}
              disabled={pumpState.state === 'ON' || isTankLow}
              className={`py-3 px-3 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer shadow-xs font-mono ${
                pumpState.state === 'ON' || isTankLow
                  ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
              }`}
            >
              <Play className="w-4 h-4 fill-current" />
              <span>START PUMP</span>
            </button>
            <button
              onClick={() => onRequestAction('PUMP_STOP')}
              disabled={pumpState.state === 'OFF'}
              className={`py-3 px-3 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer font-mono ${
                pumpState.state === 'OFF'
                  ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                  : 'bg-rose-600 hover:bg-rose-700 text-white'
              }`}
            >
              <Square className="w-4 h-4" />
              <span>STOP PUMP</span>
            </button>
          </div>

          {isTankLow && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>
                <strong>Pump Lock Active:</strong> Water reservoir level is {telemetry?.water_level}%. Minimum 20% required to prevent dry pump damage.
              </span>
            </div>
          )}

          {/* Safeguards Grid */}
          <div className="border-t border-slate-100 pt-3 grid grid-cols-3 gap-2 text-center text-xs">
            <div>
              <p className="text-[10px] uppercase text-slate-500 font-mono">Max Runtime</p>
              <p className="font-bold text-[#0C3823] font-mono">15 Mins Cap</p>
            </div>
            <div>
              <p className="text-[10px] uppercase text-slate-500 font-mono">Pump Cooldown</p>
              <p className="font-bold text-[#0C3823] font-mono">10 Mins Delay</p>
            </div>
            <div>
              <p className="text-[10px] uppercase text-slate-500 font-mono">Dry-Run Lock</p>
              <p className="font-bold text-emerald-700 font-mono">Tank &gt; 20%</p>
            </div>
          </div>
        </div>

        {/* Irrigation History & Water Usage Audit Log */}
        <div className="lg:col-span-6 bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <h3 className="text-xs font-bold text-[#0C3823] uppercase tracking-wider border-b border-slate-100 pb-3 flex items-center space-x-2 font-mono">
              <History className="w-4 h-4 text-emerald-600" />
              <span>Irrigation Events & Water Dispatch Log</span>
            </h3>
            <div className="mt-3 space-y-2 max-h-72 overflow-y-auto text-xs font-mono">
              {logs.length === 0 ? (
                <p className="text-slate-400 py-8 text-center italic font-sans">No irrigation cycles dispatched in current session</p>
              ) : (
                logs.map((log) => (
                  <div
                    key={log.id}
                    className="p-2.5 bg-[#f7f9f5] rounded-lg border border-slate-200 flex justify-between items-center text-[11px]"
                  >
                    <span>
                      <strong className={log.action === 'ON' ? 'text-emerald-700' : 'text-slate-700'}>
                        [RELAY 1] {log.action}
                      </strong>{' '}
                      <span className="text-slate-600">- {log.reason}</span>
                    </span>
                    <span className="text-slate-400 shrink-0 ml-2">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900 flex items-start space-x-2.5">
            <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <span>
              <strong>Precision Fertigation Tip:</strong> Pulse irrigation cycles (3 minutes on, 10 minutes rest) maximize nutrient absorption in the root zone while preventing nutrient leaching.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
