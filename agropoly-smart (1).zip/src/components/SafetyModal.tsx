import React from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface SafetyModalProps {
  actionType: 'PUMP_START' | 'PUMP_STOP' | 'FAN_START' | 'FAN_STOP' | null;
  onConfirm: () => void;
  onClose: () => void;
}

export const SafetyModal: React.FC<SafetyModalProps> = ({
  actionType,
  onConfirm,
  onClose,
}) => {
  if (!actionType) return null;

  const getDetails = () => {
    switch (actionType) {
      case 'PUMP_START':
        return {
          title: 'Confirm Manual Drip Pump Activation',
          desc: 'This will energize 5V Relay 1 (GPIO 26) and start pressurized nutrient water distribution to crop beds.',
          warning: 'Automatic safety shutoff is active after 15 minutes of continuous operation.',
          confirmText: 'Yes, Start Pump',
          confirmBg: 'bg-emerald-700 hover:bg-emerald-800',
        };
      case 'PUMP_STOP':
        return {
          title: 'Confirm Drip Pump Deactivation',
          desc: 'This will de-energize Relay 1 (GPIO 26) and halt all irrigation lines immediately.',
          warning: 'Ensure minimum crop daily water intake requirements have been fulfilled.',
          confirmText: 'Yes, Stop Pump',
          confirmBg: 'bg-rose-700 hover:bg-rose-800',
        };
      case 'FAN_START':
        return {
          title: 'Confirm Manual Exhaust Fan Activation',
          desc: 'This will engage Relay 2 (GPIO 27) to activate gable extraction fans and exhaust hot canopy air.',
          warning: 'Exhaust fans will alter relative humidity and CO2 enrichment levels.',
          confirmText: 'Yes, Start Fan',
          confirmBg: 'bg-amber-700 hover:bg-amber-800',
        };
      case 'FAN_STOP':
        return {
          title: 'Confirm Exhaust Fan Deactivation',
          desc: 'This will disengage Relay 2 (GPIO 27) and allow thermal buildup to stabilize.',
          warning: 'Monitor ambient temperature if ambient sunlight is strong.',
          confirmText: 'Yes, Stop Fan',
          confirmBg: 'bg-slate-700 hover:bg-slate-800',
        };
    }
  };

  const info = getDetails();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs font-mono">
      <div className="bg-white w-full max-w-md rounded-2xl p-6 border border-emerald-900/20 shadow-xl space-y-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-amber-50 text-amber-700 rounded-xl border border-amber-200">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#0C3823] uppercase">{info.title}</h3>
              <p className="text-[10px] text-slate-500 font-sans">Hardware Relay Confirmation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2.5 text-xs">
          <p className="text-slate-600 leading-relaxed text-xs font-sans">{info.desc}</p>
          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 text-[11px] font-sans">
            <strong>Notice:</strong> {info.warning}
          </div>
        </div>

        <div className="flex space-x-2.5 pt-2">
          <button
            onClick={onClose}
            className="w-1/2 py-2.5 px-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-bold text-slate-700 cursor-pointer transition shadow-xs"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className={`w-1/2 py-2.5 px-3 rounded-xl text-white text-xs font-bold cursor-pointer transition shadow-xs ${info.confirmBg}`}
          >
            {info.confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};
