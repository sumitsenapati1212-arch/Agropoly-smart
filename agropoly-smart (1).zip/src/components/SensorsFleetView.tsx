import React, { useState } from 'react';
import { RefreshCw, CheckCircle2, AlertCircle, Cpu, Radio, ShieldCheck, Zap } from 'lucide-react';
import { TelemetryPacket, CropProfile } from '../types';

interface SensorsFleetViewProps {
  telemetry: TelemetryPacket | null;
  isOnline: boolean;
  cropProfile: CropProfile;
}

export const SensorsFleetView: React.FC<SensorsFleetViewProps> = ({
  telemetry,
  isOnline,
  cropProfile,
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanMessage, setScanMessage] = useState<string | null>(null);

  const handleScanPins = () => {
    setIsScanning(true);
    setScanMessage('Interrogating I2C, UART, ADC & GPIO bus lines...');
    setTimeout(() => {
      setIsScanning(false);
      setScanMessage('✓ All 6 sensor buses and 2 relay actuation channels acknowledged (ESP32 OK)');
      setTimeout(() => setScanMessage(null), 4000);
    }, 1200);
  };

  const sensorFleet = [
    {
      id: 'temp',
      name: 'Air Temperature',
      model: 'DHT22 / AM2302',
      pin: 'GPIO 4 (Digital 1-Wire)',
      reading: telemetry?.temperature !== undefined ? `${telemetry.temperature} °C` : '--',
      threshold: `${cropProfile.tempRange[0]} - ${cropProfile.tempRange[1]} °C`,
      status: isOnline ? 'ONLINE' : 'STANDBY',
      lastSeen: telemetry?.timestamp ? new Date(telemetry.timestamp).toLocaleTimeString() : '--',
    },
    {
      id: 'hum',
      name: 'Relative Humidity',
      model: 'DHT22 Capacitive',
      pin: 'GPIO 4 (Digital 1-Wire)',
      reading: telemetry?.humidity !== undefined ? `${telemetry.humidity} %` : '--',
      threshold: `${cropProfile.humRange[0]} - ${cropProfile.humRange[1]} %`,
      status: isOnline ? 'ONLINE' : 'STANDBY',
      lastSeen: telemetry?.timestamp ? new Date(telemetry.timestamp).toLocaleTimeString() : '--',
    },
    {
      id: 'soil',
      name: 'Soil Moisture Probe',
      model: 'Capacitive V1.2 Corrosion Resistant',
      pin: 'GPIO 34 (ADC1 Channel 6)',
      reading: telemetry?.soil_moisture !== undefined ? `${telemetry.soil_moisture} %` : '--',
      threshold: `> ${cropProfile.soilTarget} %`,
      status: isOnline ? 'ONLINE' : 'STANDBY',
      lastSeen: telemetry?.timestamp ? new Date(telemetry.timestamp).toLocaleTimeString() : '--',
    },
    {
      id: 'light',
      name: 'Light Intensity Sensor',
      model: 'BH1750 Digital Lux',
      pin: 'GPIO 21 (SDA) / GPIO 22 (SCL)',
      reading: telemetry?.light !== undefined ? `${telemetry.light.toLocaleString()} lux` : '--',
      threshold: cropProfile.light,
      status: isOnline ? 'ONLINE' : 'STANDBY',
      lastSeen: telemetry?.timestamp ? new Date(telemetry.timestamp).toLocaleTimeString() : '--',
    },
    {
      id: 'co2',
      name: 'Carbon Dioxide (CO₂)',
      model: 'MH-Z19 NDIR Optical UART',
      pin: 'GPIO 16 (RX2) / GPIO 17 (TX2)',
      reading: telemetry?.co2 !== undefined ? `${telemetry.co2} ppm` : '--',
      threshold: cropProfile.co2,
      status: isOnline ? 'ONLINE' : 'STANDBY',
      lastSeen: telemetry?.timestamp ? new Date(telemetry.timestamp).toLocaleTimeString() : '--',
    },
    {
      id: 'tank',
      name: 'Water Tank Level Sensor',
      model: 'Ultrasonic HC-SR04 Transducer',
      pin: 'GPIO 18 (Trig) / GPIO 19 (Echo)',
      reading: telemetry?.water_level !== undefined ? `${telemetry.water_level} %` : '--',
      threshold: '> 20 % (Dry-Run Cutoff)',
      status: isOnline ? 'ONLINE' : 'STANDBY',
      lastSeen: telemetry?.timestamp ? new Date(telemetry.timestamp).toLocaleTimeString() : '--',
    },
  ];

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <h2 className="text-base font-bold text-white font-mono uppercase tracking-wider">
            Polyhouse Sensor Fleet & Pin Topology
          </h2>
          <p className="text-xs text-slate-400 font-mono">
            Hardware wiring topology, GPIO allocation, calibrated ranges, and real-time packet latency
          </p>
        </div>
        <button
          onClick={handleScanPins}
          disabled={isScanning}
          className="inline-flex items-center space-x-2 bg-slate-900 border border-slate-700 hover:bg-slate-800 px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold text-slate-200 transition cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin text-emerald-400' : 'text-slate-400'}`} />
          <span>{isScanning ? 'Scanning Buses...' : 'Check Sensor Link Pins'}</span>
        </button>
      </div>

      {scanMessage && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-xs font-mono font-bold text-emerald-300 flex items-center space-x-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{scanMessage}</span>
        </div>
      )}

      {/* Sensor Fleet Table */}
      <div className="bg-[#1E293B] rounded-lg border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-xs divide-y divide-slate-800">
            <thead className="bg-[#0F172A] text-slate-400 font-mono font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="px-5 py-3">Sensor Parameter</th>
                <th className="px-5 py-3">Physical Model & GPIO Pin</th>
                <th className="px-5 py-3">Live Reading</th>
                <th className="px-5 py-3">Calibrated Target</th>
                <th className="px-5 py-3">Hardware Status</th>
                <th className="px-5 py-3">Last Communication</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono text-slate-300">
              {sensorFleet.map((s) => (
                <tr key={s.id} className="hover:bg-slate-800/40 transition">
                  <td className="px-5 py-3 font-bold text-white">{s.name}</td>
                  <td className="px-5 py-3 text-[11px] text-slate-400">
                    <span className="font-semibold text-slate-200">{s.model}</span>
                    <span className="block text-slate-500">{s.pin}</span>
                  </td>
                  <td className="px-5 py-3 font-black text-emerald-400 text-sm">{s.reading}</td>
                  <td className="px-5 py-3 text-slate-400">{s.threshold}</td>
                  <td className="px-5 py-3">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        isOnline ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {isOnline ? '● ONLINE' : '○ STANDBY'}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-slate-500 text-[11px]">{s.lastSeen}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Actuator Relay Status Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="bg-[#1E293B] p-4 rounded-lg border border-slate-800 space-y-2">
          <div className="flex justify-between items-start">
            <div className="flex items-center space-x-2.5">
              <div className="p-2 bg-blue-500/10 text-blue-400 rounded-md border border-blue-500/30">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white font-mono uppercase">Relay Channel 1: Drip Pump</h4>
                <p className="text-[10px] text-slate-400 font-mono">ESP32 Pin: GPIO 26 | 5V Optocoupler Relay</p>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-blue-500/10 text-blue-400 border border-blue-500/30 uppercase">
              RELAY 1
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono leading-relaxed">
            Drives high-pressure booster pump feeding 16mm inline emitter drippers. Protected with a 15-minute runtime ceiling and dry-tank interlock.
          </p>
        </div>

        <div className="bg-[#1E293B] p-4 rounded-lg border border-slate-800 space-y-2">
          <div className="flex justify-between items-start">
            <div className="flex items-center space-x-2.5">
              <div className="p-2 bg-amber-500/10 text-amber-400 rounded-md border border-amber-500/30">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white font-mono uppercase">Relay Channel 2: Exhaust Fan</h4>
                <p className="text-[10px] text-slate-400 font-mono">ESP32 Pin: GPIO 27 | 5V Optocoupler Relay</p>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30 uppercase">
              RELAY 2
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono leading-relaxed">
            Regulates polyhouse gable exhaust ventilation. Discharges hot stagnant air pockets and draws fresh airflow across evaporative cooling pads.
          </p>
        </div>
      </div>
    </div>
  );
};
