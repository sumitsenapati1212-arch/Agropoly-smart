import React from 'react';
import {
  Fan,
  Cpu,
  Sliders,
  Wind,
  Square,
  Thermometer,
  Zap,
  Info,
  Shield,
} from 'lucide-react';
import { ActuatorState, TelemetryPacket, CropProfile } from '../types';

interface VentilationViewProps {
  fanState: ActuatorState;
  telemetry: TelemetryPacket | null;
  cropProfile: CropProfile;
  onSetFanMode: (mode: 'AUTO' | 'MANUAL') => void;
  onSetThreshold: (val: number) => void;
  onRequestAction: (action: 'FAN_START' | 'FAN_STOP') => void;
}

export const VentilationView: React.FC<VentilationViewProps> = ({
  fanState,
  telemetry,
  cropProfile,
  onSetFanMode,
  onSetThreshold,
  onRequestAction,
}) => {
  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-base font-bold text-[#0C3823] font-mono uppercase tracking-wider flex items-center space-x-2">
            <Wind className="w-5 h-5 text-emerald-600" />
            <span>Ventilation, Exhaust Fans & Microclimate Cooling</span>
          </h2>
          <p className="text-xs text-slate-600">
            Automated thermal regulation relay interfaced with ESP32 (GPIO 27) with VPD balancing
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Fan Control Card */}
        <div className="bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-amber-50 text-amber-600 rounded-xl border border-amber-200">
                <Fan className={`w-5 h-5 ${fanState.state === 'ON' ? 'animate-spin text-amber-600' : ''}`} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#0C3823] uppercase font-mono">Polyhouse Exhaust Fan Relay</h3>
                <p className="text-[11px] text-slate-500 font-mono">ESP32 Pin: GPIO 27 | Relay Channel 2</p>
              </div>
            </div>
            <span
              className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase border font-mono ${
                fanState.state === 'ON'
                  ? 'bg-amber-100 text-amber-800 border-amber-300 animate-pulse'
                  : 'bg-slate-100 text-slate-600 border-slate-200'
              }`}
            >
              {fanState.state === 'ON' ? 'RUNNING (EXHAUSTING)' : 'STANDBY (OFF)'}
            </span>
          </div>

          {/* Temperature Slider */}
          <div className="p-4 bg-[#f7f9f5] rounded-xl border border-emerald-900/10 space-y-2">
            <div className="flex justify-between text-xs font-bold font-mono">
              <span className="text-[#0C3823]">Automatic Exhaust Trigger:</span>
              <span className="text-amber-700">Air Temp &gt; {fanState.threshold.toFixed(1)} °C</span>
            </div>
            <input
              type="range"
              min="22"
              max="38"
              step="0.5"
              value={fanState.threshold}
              onChange={(e) => onSetThreshold(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#0C3823]"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>22 °C (Cool Season)</span>
              <span>30 °C (Standard Setpoint)</span>
              <span>38 °C (Extreme Thermal Cap)</span>
            </div>
          </div>

          {/* Mode Selector */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => onSetFanMode('AUTO')}
              className={`py-2.5 px-3 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer font-mono ${
                fanState.mode === 'AUTO'
                  ? 'border border-emerald-600 bg-emerald-50 text-emerald-800 shadow-xs'
                  : 'border border-slate-200 bg-[#f7f9f5] text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>AUTO REGULATION</span>
            </button>
            <button
              onClick={() => onSetFanMode('MANUAL')}
              className={`py-2.5 px-3 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer font-mono ${
                fanState.mode === 'MANUAL'
                  ? 'border border-emerald-600 bg-emerald-50 text-emerald-800 shadow-xs'
                  : 'border border-slate-200 bg-[#f7f9f5] text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>MANUAL OVERRIDE</span>
            </button>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              onClick={() => onRequestAction('FAN_START')}
              disabled={fanState.state === 'ON'}
              className={`py-3 px-3 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer shadow-xs font-mono ${
                fanState.state === 'ON'
                  ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                  : 'bg-amber-600 hover:bg-amber-700 text-white'
              }`}
            >
              <Wind className="w-4 h-4" />
              <span>START EXHAUST FAN</span>
            </button>
            <button
              onClick={() => onRequestAction('FAN_STOP')}
              disabled={fanState.state === 'OFF'}
              className={`py-3 px-3 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer font-mono ${
                fanState.state === 'OFF'
                  ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                  : 'bg-slate-200 hover:bg-slate-300 text-slate-800 border border-slate-300'
              }`}
            >
              <Square className="w-4 h-4" />
              <span>STOP FAN</span>
            </button>
          </div>
        </div>

        {/* Evaporative Pad, VPD & Cooling Guidance */}
        <div className="bg-white p-5 rounded-xl border border-emerald-900/10 shadow-xs space-y-3">
          <h3 className="text-xs font-bold text-[#0C3823] uppercase tracking-wider border-b border-slate-100 pb-2 font-mono">
            Vapor Pressure Deficit (VPD) & Thermal Guidance
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200 space-y-1">
              <strong className="text-emerald-900 block font-bold font-mono">
                Target VPD ({cropProfile.name}): {cropProfile.vpdTarget}
              </strong>
              <p className="text-emerald-800 leading-relaxed text-[11px]">
                Vapor Pressure Deficit measures drying power of air. Maintaining VPD between 0.8 to 1.2 kPa ensures maximum stomatal conductance, calcium mobility, and prevents blossom-end rot.
              </p>
            </div>

            <div className="p-3.5 bg-[#f7f9f5] rounded-xl border border-slate-200 space-y-1">
              <strong className="text-slate-800 block font-bold font-mono">
                Night Chilling Interlock:
              </strong>
              <p className="text-slate-600 leading-relaxed text-[11px]">
                Exhaust fans automatically lockout if external temperature drops below 18°C to prevent nighttime condensation shock and vegetative chilling injury.
              </p>
            </div>

            <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
              <strong className="text-amber-900 block font-bold font-mono">
                CO₂ Enrichment Synchronization:
              </strong>
              <p className="text-amber-800 leading-relaxed text-[11px]">
                During active morning photosynthesis (07:00 - 10:30), fan operation is minimized where possible to retain high CO₂ concentrations (700-1000 ppm) inside the canopy.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
