export interface TelemetryPacket {
  device_id: string;
  temperature: number;
  humidity: number;
  soil_moisture: number;
  light: number;
  co2: number;
  water_level: number;
  timestamp: string;
}

export interface CropProfile {
  name: string;
  scientificName: string;
  tempRange: [number, number];
  humRange: [number, number];
  soilTarget: number;
  light: string;
  co2: string;
  stages: string;
  diseases: string[];
  pests: string[];
  vpdTarget: string;
  idealEcPh: string;
}

export interface ActuatorState {
  state: 'ON' | 'OFF';
  mode: 'AUTO' | 'MANUAL';
  threshold: number;
}

export interface IrrigationLogEntry {
  id: string;
  timestamp: string;
  action: 'ON' | 'OFF';
  reason: string;
  volumeLiters?: number;
}

export interface NutrientDeficiencyReport {
  element: string; // e.g. "Iron (Fe)", "Magnesium (Mg)", "Nitrogen (N)", "Potassium (K)", "Calcium (Ca)"
  severity: 'Mild' | 'Moderate' | 'Severe' | 'None Detected';
  visualSigns: string;
  prescription: string;
  dosage: string;
  stockTank: 'Tank A' | 'Tank B' | 'Tank C (Micro)' | 'Foliar Spray';
}

export interface LeafDiagnosisResult {
  diagnosedName: string;
  causalAgent: string;
  confidence: string;
  symptoms: string;
  ipmRecommendations: string[];
  nutrientDeficiency?: NutrientDeficiencyReport;
  source?: string;
}

export type ViewTab =
  | 'dashboard'
  | 'sensors'
  | 'history'
  | 'irrigation'
  | 'ventilation'
  | 'crops'
  | 'ai-scanner'
  | 'fertilizer'
  | 'weather'
  | 'calculator'
  | 'iot-setup';
